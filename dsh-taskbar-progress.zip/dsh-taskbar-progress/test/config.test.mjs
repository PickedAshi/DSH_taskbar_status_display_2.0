/**
 * 配置规整的单测 —— 重点是 v2.0 的 **volatile 盒子**语义。
 *
 * `.volatile()` 的配置字段在 Cordis 里不是裸值，而是 cosmokit 的 `Volatile` 盒子
 * （`JSON.stringify` 出来是 `{}`），取值要 `.get()`。设置界面靠它做到"改完立即生效、
 * 不用重启"。这里用最小的假盒子验证四件事：
 *   1. 裸值照旧工作（link: 安装退化时就是这种形态）；
 *   2. 盒子能被解包，值被采用；
 *   3. **实时**：盒子里换值后，重新读 `settings.x` 拿到的是新值；
 *   4. 盒子里是坏值时回落默认值，而不是把坏值喂给插件。
 *
 *   node test/config.test.mjs
 */

import assert from 'node:assert/strict'
import { normalizeConfig, FAILURE_NOTICE_TEXT } from '../lib/index.js'

let passed = 0
const check = (label, fn) => {
  fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}

/** 造一个最小的 volatile 盒子（够用的子集：只有 get）。 */
function box(getValue) {
  return { get: getValue, set() {}, subscribe: () => () => {} }
}

console.log('config normalization')

check('裸值照常工作', () => {
  const { settings, warnings } = normalizeConfig({ waitingNotifyText: '甲', waitingNotifyDelayMs: '5000' })
  assert.equal(settings.waitingNotifyText, '甲')
  assert.equal(settings.waitingNotifyDelayMs, 5000, '数字字符串应被接受')
  assert.deepEqual(warnings, [])
})

check('没给的键用默认值', () => {
  const { settings } = normalizeConfig({})
  assert.equal(settings.notifyPersona, '大肥鱼')
  assert.equal(settings.waitingNotifyEnabled, true)
  assert.equal(settings.waitingNotifyDelayMs, 30_000)
  assert.equal(settings.reviewNotifyDelayMs, 15_000)
  assert.equal(settings.driftNotifyMinutes, 10)
})

check('volatile 盒子会被解包，值被采用', () => {
  const { settings } = normalizeConfig({
    waitingNotifyText: box(() => '来自设置界面'),
    waitingNotifyEnabled: box(() => false),
    driftNotifyMinutes: box(() => 3),
  })
  assert.equal(settings.waitingNotifyText, '来自设置界面')
  assert.equal(settings.waitingNotifyEnabled, false)
  assert.equal(settings.driftNotifyMinutes, 3)
})

check('volatile 盒子是实时的：换值后重新读就是新值', () => {
  let text = '第一版'
  let delay = 1000
  const { settings } = normalizeConfig({
    waitingNotifyText: box(() => text),
    waitingNotifyDelayMs: box(() => delay),
  })
  assert.equal(settings.waitingNotifyText, '第一版')
  // 模拟用户在设置界面里保存 —— 不重启 DSH
  text = '改过了'
  delay = 60_000
  assert.equal(settings.waitingNotifyText, '改过了', '不做快照，每次读都取当前值')
  assert.equal(settings.waitingNotifyDelayMs, 60_000)
})

check('盒子里是坏值 → 回落默认值（而不是把坏值喂给插件）', () => {
  const { settings } = normalizeConfig({
    waitingNotifyDelayMs: box(() => '不是数字'),
    waitingNotifyText: box(() => 12345),
    completion: box(() => '不认识的模式'),
  })
  assert.equal(settings.waitingNotifyDelayMs, 30_000)
  assert.equal(settings.waitingNotifyText, '老大请您做出决定')
  assert.equal(settings.completion, 'hold')
})

check('盒子先坏后好也能恢复（设置界面改回来就生效）', () => {
  let value = null
  const { settings } = normalizeConfig({ driftNotifyMinutes: box(() => value) })
  assert.equal(settings.driftNotifyMinutes, 10, '坏值期间用默认值')
  value = 7
  assert.equal(settings.driftNotifyMinutes, 7, '改好后立刻生效')
})

check('未知配置项被忽略并给出警告', () => {
  const { warnings } = normalizeConfig({ 不存在的键: 1 })
  assert.equal(warnings.length, 1)
  assert.match(warnings[0], /未知配置项/)
})

check('枚举值非法 → 回落默认值并给出警告', () => {
  const { settings, warnings } = normalizeConfig({ backend: 'magic' })
  assert.equal(settings.backend, 'auto')
  assert.equal(warnings.length, 1)
})

check('整份配置不是对象 → 全部默认值 + 一条警告', () => {
  const { settings, warnings } = normalizeConfig('不是对象')
  assert.equal(settings.enabled, true)
  assert.equal(warnings.length, 1)
})

check('故障文案是写死的常量，配置改不动', () => {
  assert.equal(FAILURE_NOTICE_TEXT, '故障，请检查')
  // 全部键里都没有"故障"相关的覆盖项
  const { settings } = normalizeConfig({ failureNotifyText: '换个说法', failureNotifyEnabled: false })
  assert.equal(Object.prototype.hasOwnProperty.call(settings, 'failureNotifyText'), false)
  assert.equal(Object.prototype.hasOwnProperty.call(settings, 'failureNotifyEnabled'), false)
})

console.log(`\nconfig normalization: ${passed} 项全部通过\n`)
