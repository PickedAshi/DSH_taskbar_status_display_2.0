/**
 * 后端实测工具：把真实任务栏依次推过 5 个相位，方便肉眼确认颜色。
 *
 *   node test/backend-smoke.mjs                 # 自动选后端，完整走一遍（每相位 3s）
 *   node test/backend-smoke.mjs --ms 5000       # 每相位停 5s
 *   node test/backend-smoke.mjs --phase error   # 只设一个相位并**留在这里**（便于截图/肉眼核对）
 *   node test/backend-smoke.mjs --backend powershell
 *
 * 需要目标窗口 PID 时用环境变量（默认自动取 process.ppid，在 DSH 宿主里就是 Electron 主进程）：
 *   DSH_TASKBAR_TARGET_PID=<pid> node test/backend-smoke.mjs
 * koffi 找不到时可以用 DSH_TASKBAR_KOFFI=<koffi 包目录> 显式指定。
 */

import { createTaskbarController } from '../lib/taskbar.js'
import { PHASE, PHASE_SPEC } from '../lib/status-map.js'

const argv = process.argv.slice(2)
const arg = (name, fallback) => {
  const index = argv.indexOf(`--${name}`)
  return index >= 0 && argv[index + 1] !== undefined ? argv[index + 1] : fallback
}

const ms = Number(arg('ms', 3000))
const onlyPhase = arg('phase', null)
const backend = arg('backend', 'auto')
const targetPid = Number(process.env.DSH_TASKBAR_TARGET_PID ?? 0)

const log = (level, message) => console.log(`[${level}] ${message}`)
const sleep = (duration) => new Promise((resolve) => setTimeout(resolve, duration))

const ORDER = [PHASE.WORKING, PHASE.WAITING, PHASE.ERROR, PHASE.DONE, PHASE.IDLE]

const controller = await createTaskbarController({
  // 一个"空"的 DSH 上下文：窗口服务探测会安全地返回 null，于是继续往后端 2/3 降级。
  ctx: { get: () => undefined },
  config: {
    backend,
    targetPid,
    completion: 'hold',
    completionHoldMs: 30_000,
    errorHoldMs: 60_000,
    logStateChanges: true,
  },
  log,
})

console.log(`\n后端：${controller.backendId} —— ${controller.describe}\n`)

if (controller.backendId === 'no-op') {
  console.error('没有可用后端；本机可能是非 Windows，或 koffi/PowerShell 都不可用。')
  process.exitCode = 1
} else {
  const phases = onlyPhase === null ? ORDER : [onlyPhase]
  for (const phase of phases) {
    const spec = PHASE_SPEC[phase]
    console.log(`→ ${phase.padEnd(11)} mode=${spec.mode} value=${spec.value}`)
    controller.applyPhase(phase, true)
    if (onlyPhase === null) await sleep(ms)
  }
  if (onlyPhase === null) {
    controller.dispose()
    console.log('\n已依次走完 5 个相位，任务栏进度条已清除。')
  } else {
    // 单相位模式：**故意不 dispose**，退出后进度条状态会留在任务栏上，
    // 方便外部脚本截图核对（实测设置进程退出后状态保持）。
    console.log(`\n已设置 ${onlyPhase} 并保留（未清除）。`)
    console.log('要清除请再跑一次：--phase idle')
    // 留一点时间让写入落到后端（PowerShell 后端是异步管道），然后显式退出：
    // 否则常驻助手进程会把事件循环拖住不退出。
    await sleep(400)
    process.exit(0)
  }
}
