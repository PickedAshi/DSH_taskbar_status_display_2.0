/**
 * `lib/client.js`（浏览器半边）的**结构级回归测试**。
 *
 * ## 为什么需要它
 * `lib/client.js` 是跑在 DSH Web 客户端里的模块，跟本仓库其它测试完全不在一个世界：
 * 它只能在 `window.__ModuleLoader__` + `require('react/jsx-runtime')` +
 * `require('@deepseek-ai/dsh-client-ui-primitives')` 这套加载器契约下运行，
 * 主仓库里的单测（status-map / plugin-state / reminder / …）**一个字都不会碰它**。
 * 也就是说：改坏这个文件，`npm test` 照样全绿，直到用户打开「插件 → 配置」才发现
 * 页面白屏或控件不动。所以这里用**假加载器 + 假 require + 假原语 + 假 ctx**，
 * 把它当成一个普通模块加载进来，验证下面这些**契约**：
 *
 *   1. 模块形态与注入：`id`、`NS`、`inject` 三项；
 *   2. **注册时机**：`apply()` 必须走 `ctx.configForms.whileServed([...])` 才注册
 *      `plugins.row.config` —— 宿主还没服务这个命名空间时不许注册，服务到达后才建
 *      卡片（这条是真实修过的 bug，必须有回归保护）；释放时 slot 与卡片都要被释放；
 *   3. 字段清单与 `lib/config-schema.js` 逐字段对齐；
 *   4. 渲染契约：`summary` 返回一句话、`page` 返回 SettingsForm、每个控件都拿到
 *      合法且已本地化的 prop；
 *   5. 依赖逻辑：某组开关关掉后，该组两个输入框 `disabled`，**其它组不受影响**；
 *   6. UI 硬性要求：页面上不出现「故障」相关任何东西，也不出现 v1 的旧配置键名；
 *   7. 中英两套字典键集一致。
 *
 * 全都是"结构级"断言：这里没有真 React（本机也拿不到可解析的 react 包），
 * 真正的浏览器渲染与保存流程仍需在 DSH 桌面端里点一遍。
 *
 *   node test/client.test.mjs
 */

import assert from 'node:assert/strict'
import fs from 'node:fs'

/** 被测文件与它的参照物，都用相对路径解析，跟 cwd 无关。 */
const CLIENT_URL = new URL('../lib/client.js', import.meta.url)
const SCHEMA_URL = new URL('../lib/config-schema.js', import.meta.url)

const CLIENT_ID = 'dsh-taskbar-progress'
const NS = 'taskbarProgress'
const NAMESPACE = 'taskbar-progress'
const ROW_KEY = 'dsh-taskbar-progress#taskbar-progress'

/**
 * 期望的字段清单（顺序也要一致）。
 *
 * ⚠️ **改 `lib/config-schema.js` 时，这里必须同步改。**
 * 测试不能 `import '../lib/config-schema.js'`：那个文件 `import '@deepseek-ai/schemastery'`，
 * 而本仓库刻意零依赖（`link:` 安装时解析不到 profile 运行时包），直接跑必然失败。
 * 所以清单硬编码在这里，另外单独有一项"读文本比对"，防止两边悄悄漂移。
 */
const EXPECTED_FIELDS = [
  'notifyPersona',
  'waitingNotifyEnabled',
  'waitingNotifyText',
  'waitingNotifyDelayMs',
  'reviewNotifyEnabled',
  'reviewNotifyText',
  'reviewNotifyDelayMs',
  'driftNotifyEnabled',
  'driftNotifyText',
  'driftNotifyMinutes',
]

/** 三组提醒：开关字段 + 它管着的文案与时长。 */
const GROUPS = [
  { enabled: 'waitingNotifyEnabled', text: 'waitingNotifyText', number: 'waitingNotifyDelayMs' },
  { enabled: 'reviewNotifyEnabled', text: 'reviewNotifyText', number: 'reviewNotifyDelayMs' },
  { enabled: 'driftNotifyEnabled', text: 'driftNotifyText', number: 'driftNotifyMinutes' },
]

/** v1 的旧键名 + 故意不上界面的键：一个都不许出现在渲染结果里。 */
const BANNED_KEYS = [
  'waitingReminderMs',
  'waitingReminderText',
  'completionNudgeMs',
  'completionNudgeText',
  'notifyAumid',
  'failureNotifyEnabled',
  'failureNotifyText',
]

let passed = 0
const check = (label, fn) => {
  fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}

/**
 * 造一个"世界"：假 window 加载器 + 假 require + 假原语 + 假 ctx，并跑一次 `apply()`。
 *
 * @param options.serve - `immediate`（宿主已经报上命名空间）/ `manual`（还没报，测试自己触发）
 * @returns 这个世界里所有可断言的把手
 */
function createWorld(options = {}) {
  const serveMode = options.serve ?? 'immediate'

  // ── 记录下模块向原语要了什么 ────────────────────────────────────────────
  const calls = {
    specs: null,
    models: [],
    forms: [],
    valueFields: [],
    switches: [],
    edits: [],
    resets: [],
    saves: 0,
    discards: 0,
    modelDisposed: 0,
    slotDisposed: 0,
    registrationsInsideCallback: 0,
    duplicateKeys: [],
    effectLabels: [],
    effectDisposers: [],
    whileServedCalls: [],
  }

  // ── react/jsx-runtime 的替身 ───────────────────────────────────────────
  // 只做两件真运行时也做的事：第三个参数是 key；config 里的 key 不算 prop。
  // 真 React 里 key 只该走第三个参数，两个都给属于写法不规范 —— 这里记下来断言。
  const node = (type, config, maybeKey) => {
    const { key: configKey, ...props } = config ?? {}
    if (configKey !== undefined && maybeKey !== undefined) calls.duplicateKeys.push(String(maybeKey))
    return { type, key: maybeKey !== undefined ? maybeKey : configKey, props }
  }
  const jsxRuntime = { jsx: node, jsxs: node, Fragment: Symbol('Fragment') }

  // ── 原语替身：形状照 @deepseek-ai/dsh-client-ui-primitives 的真实实现 ──
  const primitives = {
    SettingsForm(props) {
      calls.forms.push(props)
      return node('SettingsForm', props)
    },
    SettingsValueField(props) {
      calls.valueFields.push(props)
      return node('SettingsValueField', props)
    },
    Switch(props) {
      calls.switches.push(props)
      return node('Switch', props)
    },
    settingsTextField(field) {
      return {
        field,
        format: (value) => (typeof value === 'string' ? value : ''),
        parse: (text) => (text.trim() === '' ? { kind: 'clear' } : { kind: 'set', value: text.trim() }),
      }
    },
    settingsNumberField(field) {
      return {
        field,
        format: (value) => (typeof value === 'number' ? String(value) : ''),
        parse: (text) => {
          const trimmed = text.trim()
          if (trimmed === '') return { kind: 'clear' }
          const parsed = Number(trimmed)
          return Number.isFinite(parsed) ? { kind: 'set', value: parsed } : undefined
        },
      }
    },
    SettingsFormModel: class {
      constructor(scope, specs) {
        this.scope = scope
        this.specs = specs
        calls.specs = specs
        calls.models.push(this)
        /** 假的宿主有效值；测试可以改它来模拟"开关被关掉"等场景。 */
        this.values = {
          notifyPersona: '大肥鱼',
          waitingNotifyEnabled: true,
          waitingNotifyText: '老大请您做出决定',
          waitingNotifyDelayMs: 30000,
          reviewNotifyEnabled: true,
          reviewNotifyText: '老大请验收',
          reviewNotifyDelayMs: 15000,
          driftNotifyEnabled: true,
          driftNotifyText: '已经连续工作10分钟，建议检查白饭是否被偷',
          driftNotifyMinutes: 10,
        }
      }
      bind(project) {
        this.project = project
        return { getSnapshot: () => project() }
      }
      shell() {
        return { available: true, writable: true, dirty: false, invalid: false, saving: false, failed: false }
      }
      field(name) {
        const spec = this.specs.find((item) => item.field === name)
        return { text: spec.format(this.values[name]), overridden: false, invalid: false }
      }
      actions() {
        return {
          edit: (field, text) => calls.edits.push({ field, text }),
          resetField: (field) => calls.resets.push(field),
          save: () => {
            calls.saves += 1
          },
          discard: () => {
            calls.discards += 1
          },
        }
      }
      dispose() {
        calls.modelDisposed += 1
      }
    },
  }

  // ── 用假加载器把真文件加载进来 ─────────────────────────────────────────
  let registration = null
  globalThis.window = {
    __ModuleLoader__: {
      load(reg) {
        registration = reg
      },
    },
  }
  new Function(fs.readFileSync(CLIENT_URL, 'utf8'))()
  assert.ok(registration, 'client.js 必须调用 window.__ModuleLoader__.load({ id, factory })')

  const moduleExports = registration.factory((specifier) => {
    if (specifier === 'react/jsx-runtime') return jsxRuntime
    if (specifier === '@deepseek-ai/dsh-client-ui-primitives') return primitives
    throw new Error(`client.js require 了计划外的模块：${specifier}`)
  })

  // ── 假 ctx ─────────────────────────────────────────────────────────────
  const dictionaries = []
  const missingKeys = new Set()
  let activeLocale = 'zh'
  const lookup = (key) => {
    const dict = dictionaries[0]?.dicts[activeLocale]
    if (dict?.[key] === undefined) missingKeys.add(`${activeLocale}:${key}`)
    return dict?.[key] ?? key
  }

  const scope = {
    subscribe: () => () => {},
    getSnapshot: () => ({ status: 'ready', writable: true, value: {}, base: {}, user: {} }),
    mutate: async () => true,
  }

  const registry = []
  const pendingServes = []
  let insideServeCallback = false
  const ctx = {
    effect(fn, label) {
      calls.effectLabels.push(label)
      const dispose = fn()
      calls.effectDisposers.push(typeof dispose === 'function' ? dispose : () => {})
      return () => {
        if (typeof dispose === 'function') dispose()
      }
    },
    locale: {
      bind(ns) {
        assert.equal(ns, NS, '字典命名空间')
        return lookup
      },
      register(ns, dicts) {
        assert.equal(ns, NS, '字典命名空间')
        dictionaries.push({ ns, dicts })
        return () => {}
      },
    },
    configForms: {
      get(ns) {
        assert.equal(ns, NAMESPACE, '设置命名空间必须是行 id')
        return scope
      },
      whileServed(namespaces, register) {
        calls.whileServedCalls.push(namespaces)
        let off
        const sync = () => {
          if (serveMode !== 'immediate' || off !== undefined) return
          insideServeCallback = true
          try {
            off = register(new Set(namespaces))
          } finally {
            insideServeCallback = false
          }
        }
        if (serveMode !== 'immediate') {
          // 手动模式：宿主还没报上命名空间，测试稍后自己调用这个回调
          pendingServes.push(() => {
            insideServeCallback = true
            try {
              off = register(new Set(namespaces))
            } finally {
              insideServeCallback = false
            }
          })
        }
        sync()
        return () => {
          off?.()
          off = undefined
        }
      },
    },
    slots: {
      inject(slotName, callback) {
        assert.equal(slotName, 'plugins.row.config', '座位名')
        const dispose = callback()
        return typeof dispose === 'function' ? dispose : () => {}
      },
      register(options, component) {
        if (insideServeCallback) calls.registrationsInsideCallback += 1
        registry.push({ options, component })
        return () => {
          calls.slotDisposed += 1
        }
      },
    },
  }

  return {
    registration,
    moduleExports,
    ctx,
    calls,
    scope,
    registry,
    dictionaries,
    missingKeys,
    pendingServes,
    get activeLocale() {
      return activeLocale
    },
    setLocale(locale) {
      activeLocale = locale
    },
    /** 当前注册项（slot 被释放后就没有了）。 */
    current() {
      return registry.at(-1)
    },
    /** 走一遍 renderer 的 bindInjectSources：hooks → use<Name>。 */
    face() {
      const { hooks, ...rest } = this.current().options.inject()
      const props = { ...rest }
      for (const [name, source] of Object.entries(hooks ?? {})) {
        props[`use${name[0].toUpperCase()}${name.slice(1)}`] = (selector) => selector(source.getSnapshot())
      }
      return props
    },
    /** 渲染一次（不经过真 React，只调用组件拿元素树）。 */
    render(view) {
      const { component } = this.current()
      return component({
        view,
        t: lookup,
        form: scope,
        ...this.face(),
      })
    },
    /** 收集一棵元素树里的全部可见文案。 */
    texts(element) {
      const out = []
      const walk = (value) => {
        if (value === null || value === undefined || typeof value === 'boolean') return
        if (typeof value === 'string' || typeof value === 'number') {
          out.push(String(value))
          return
        }
        if (Array.isArray(value)) {
          value.forEach(walk)
          return
        }
        if (typeof value === 'object' && 'props' in value) {
          if (typeof value.type === 'function') walk(value.type(value.props))
          else walk(value.props.children)
        }
      }
      walk(element)
      return out
    },
    /** 清掉上一次渲染记下的控件，便于分组断言。 */
    resetRendered() {
      calls.forms.length = 0
      calls.valueFields.length = 0
      calls.switches.length = 0
    },
    /** 一次"渲染 + 收集文案 + 记录控件"的组合动作。 */
    paint(overrides = {}, view = 'page') {
      const model = calls.models.at(-1)
      for (const [field, value] of Object.entries(overrides)) model.values[field] = value
      this.resetRendered()
      const element = this.render(view)
      return { element, texts: this.texts(element) }
    },
    /** 某个输入框当前是不是禁用。 */
    disabled(field) {
      const control = calls.valueFields.find((item) => item.id === `plugin-config-taskbar-progress-${field}`)
      assert.ok(control, `渲染结果里应有字段 ${field}`)
      return control.disabled
    },
  }
}

/** 页面文案 + 所有控件收到的文案，合起来就是用户实际看得见的东西。 */
const visibleCopy = (world, texts) =>
  [
    ...texts,
    ...world.calls.valueFields.flatMap((field) => [field.label, field.hint]),
    ...world.calls.switches.map((sw) => sw.label),
    ...Object.values(world.calls.forms.at(-1).labels),
  ].join('\n')

console.log('client (browser half)')

// ── 1. 模块形态 ────────────────────────────────────────────────────────────
check('模块形态：id / NS / inject 三项服务', () => {
  const world = createWorld()
  assert.equal(world.registration.id, CLIENT_ID)
  assert.equal(world.moduleExports.NS, NS)
  assert.deepEqual(world.moduleExports.inject, ['slots', 'locale', 'configForms'])
  assert.equal(typeof world.moduleExports.apply, 'function')
})

// ── 2. 注册时机：必须经 whileServed ────────────────────────────────────────
check('apply 经 ctx.configForms.whileServed 注册 slot（而不是抢先注册）', () => {
  const world = createWorld({ serve: 'immediate' })
  world.moduleExports.apply(world.ctx)
  assert.deepEqual(world.calls.whileServedCalls, [[NAMESPACE]], 'whileServed 必须盯住本插件的命名空间')
  assert.equal(world.calls.registrationsInsideCallback, 1, 'slot 必须在 whileServed 的回调里注册')
  assert.equal(world.registry.length, 1)
  const { options } = world.current()
  assert.equal(options.name, 'plugins.row.config')
  assert.equal(options.key, ROW_KEY, 'key 必须是 <包名>#<行id>')
  assert.equal(options.locale, NS)
  assert.equal(options.label(), '任务栏进度条')
  assert.ok(world.calls.effectLabels.includes('dsh-taskbar-progress: configuration page'))
})

check('宿主还没服务这个命名空间时：不注册 slot、也不建卡片', () => {
  const world = createWorld({ serve: 'manual' })
  world.moduleExports.apply(world.ctx)
  assert.deepEqual(world.calls.whileServedCalls, [[NAMESPACE]], '仍然要订阅 whileServed')
  assert.equal(world.registry.length, 0, '没服务就不该有注册项（否则插件行会多出一个点不开的「配置」）')
  assert.equal(world.calls.models.length, 0, '也不该提前建卡片')
})

check('命名空间到达后才建卡片并注册（延迟服务）', () => {
  const world = createWorld({ serve: 'manual' })
  world.moduleExports.apply(world.ctx)
  world.pendingServes[0]()
  assert.equal(world.registry.length, 1)
  assert.equal(world.calls.models.length, 1)
  assert.deepEqual(world.calls.models[0].specs.map((spec) => spec.field), EXPECTED_FIELDS)
})

check('释放 whileServed 的 effect：slot 注销 + 卡片 dispose', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  assert.equal(world.calls.slotDisposed, 0)
  assert.equal(world.calls.modelDisposed, 0)
  // effect 顺序：0=字典，1=配置页
  world.calls.effectDisposers[1]()
  assert.equal(world.calls.slotDisposed, 1, 'slot 注册要撤掉')
  assert.equal(world.calls.modelDisposed, 1, '卡片要 dispose，不能漏订阅')
})

// ── 3. 字段清单 ───────────────────────────────────────────────────────────
check('字段清单与 config-schema 的 10 个键逐字段一致（顺序也一致）', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  assert.deepEqual(world.calls.specs.map((spec) => spec.field), EXPECTED_FIELDS)
  assert.equal(world.calls.specs.length, 10)
})

check('lib/config-schema.js 文本里的键与上面清单一致（读文本，不 import）', () => {
  const source = fs.readFileSync(SCHEMA_URL, 'utf8')
  const declared = [...source.matchAll(/^\s{2}(\w+):\s*(?:bool|text|number)\(/gm)].map((match) => match[1])
  // 匹配不到说明那个文件的写法变了（不是失败，只是这条检查失效）——不误报
  if (declared.length > 0) assert.deepEqual(declared, EXPECTED_FIELDS, '两边字段漂移了：请同步本文件的 EXPECTED_FIELDS')
})

check('三个布尔字段 + 三个数字字段的解析/格式化符合表单模型契约', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const spec = (field) => world.calls.specs.find((item) => item.field === field)

  for (const group of GROUPS) {
    const bool = spec(group.enabled)
    assert.deepEqual(bool.format(true), 'true')
    assert.deepEqual(bool.format(false), 'false')
    assert.deepEqual(bool.format(undefined), '', '没值时是空串，等于"用默认"')
    assert.deepEqual(bool.parse(' true '), { kind: 'set', value: true })
    assert.deepEqual(bool.parse('false'), { kind: 'set', value: false })
    assert.deepEqual(bool.parse(''), { kind: 'clear' })
    assert.equal(bool.parse('随便'), undefined, '认不出的布尔草稿要拦住保存，而不是猜')

    const number = spec(group.number)
    assert.deepEqual(number.format(30000), '30000')
    assert.deepEqual(number.parse('30000'), { kind: 'set', value: 30000 })
    assert.deepEqual(number.parse(''), { kind: 'clear' })
    assert.equal(number.parse('三十秒'), undefined, '数字字段要拦住非数字')
  }

  const text = spec('waitingNotifyText')
  assert.deepEqual(text.parse('  老大请您做出决定  '), { kind: 'set', value: '老大请您做出决定' })
  assert.deepEqual(text.parse('   '), { kind: 'clear' })
})

// ── 4. 渲染契约 ───────────────────────────────────────────────────────────
check('注入面：form + useTaskbarCard + 四个表单动作', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const face = world.face()
  assert.equal(face.form, world.scope, '注入的 form 就是本行的设置 scope')
  assert.deepEqual(
    Object.keys(face).sort(),
    ['discard', 'edit', 'form', 'resetField', 'save', 'useTaskbarCard'],
  )
})

check('summary 视图返回一句话（不是元素）', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const summary = world.render('summary')
  assert.equal(typeof summary, 'string')
  assert.equal(summary, world.dictionaries[0].dicts.zh.summary)
  world.setLocale('en')
  assert.equal(world.render('summary'), world.dictionaries[0].dicts.en.summary)
  world.setLocale('zh')
})

check('page 视图渲染 SettingsForm：通用块 + 三组，控件 prop 齐备且 id 唯一', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const { element } = world.paint()

  assert.equal(element.type.name, 'SettingsForm')
  const form = world.calls.forms[0]
  assert.deepEqual(Object.keys(form.labels).sort(), ['readOnly', 'save', 'saveFailed', 'saving', 'unavailable'])
  assert.equal(form.state.available, true)
  assert.equal(typeof form.onSave, 'function')
  assert.equal(typeof form.onDiscard, 'function')
  assert.equal(form.children.length, 4, '通用 + 三组')

  // 七个输入框：署名 1 + 每组文案 1 + 每组时长 1
  assert.deepEqual(
    world.calls.valueFields.map((field) => field.id.replace('plugin-config-taskbar-progress-', '')),
    ['notifyPersona', ...GROUPS.flatMap((group) => [group.text, group.number])],
  )
  assert.equal(new Set(world.calls.valueFields.map((field) => field.id)).size, 7, '控件 id 必须唯一')
  for (const field of world.calls.valueFields) {
    assert.equal(typeof field.label, 'string')
    assert.equal(typeof field.hint, 'string')
    assert.ok(field.label.length > 0 && field.hint.length > 0)
    assert.equal(typeof field.numeric, 'boolean')
    assert.equal(typeof field.disabled, 'boolean')
    assert.equal(typeof field.text, 'string')
    assert.equal(typeof field.overridden, 'boolean')
    assert.equal(typeof field.invalid, 'boolean')
    assert.equal(typeof field.onEdit, 'function')
    assert.equal(typeof field.onReset, 'function')
    assert.equal(typeof field.overriddenLabel, 'string')
    assert.equal(typeof field.resetLabel, 'string')
    assert.equal(typeof field.invalidLabel, 'string')
  }
  // 只有三个时长是数字键盘
  assert.deepEqual(
    world.calls.valueFields.filter((field) => field.numeric).map((field) => field.id.replace('plugin-config-taskbar-progress-', '')),
    GROUPS.map((group) => group.number),
  )
  // 三个开关
  assert.equal(world.calls.switches.length, 3)
  assert.deepEqual(world.calls.switches.map((sw) => sw.checked), [true, true, true])
  for (const sw of world.calls.switches) {
    assert.equal(typeof sw.label, 'string')
    assert.ok(sw.label.length > 0)
    assert.equal(sw.disabled, false)
    assert.equal(typeof sw.onChange, 'function')
  }
})

check('开关点击暂存布尔编辑（true/false 文本）', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  world.paint()
  world.calls.switches[0].onChange(false)
  world.calls.switches[2].onChange(true)
  assert.deepEqual(world.calls.edits, [
    { field: 'waitingNotifyEnabled', text: 'false' },
    { field: 'driftNotifyEnabled', text: 'true' },
  ])
  // 文案框的编辑与 reset 也要接对字段
  world.calls.valueFields[1].onEdit('换个说法')
  world.calls.valueFields[1].onReset()
  assert.deepEqual(world.calls.edits.at(-1), { field: 'waitingNotifyText', text: '换个说法' })
  assert.deepEqual(world.calls.resets, ['waitingNotifyText'])
})

// ── 5. 依赖逻辑 ───────────────────────────────────────────────────────────
check('关掉某组开关：该组文案与时长禁用，其它组不受影响', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)

  world.paint({ reviewNotifyEnabled: false })
  assert.deepEqual(world.calls.switches.map((sw) => sw.checked), [true, false, true])
  assert.equal(world.disabled('reviewNotifyText'), true)
  assert.equal(world.disabled('reviewNotifyDelayMs'), true)
  assert.equal(world.disabled('waitingNotifyText'), false, '别的组不许被连坐')
  assert.equal(world.disabled('waitingNotifyDelayMs'), false)
  assert.equal(world.disabled('driftNotifyText'), false)
  assert.equal(world.disabled('driftNotifyMinutes'), false)
  assert.equal(world.disabled('notifyPersona'), false, '通用块始终可改')

  world.paint({ waitingNotifyEnabled: false, reviewNotifyEnabled: false, driftNotifyEnabled: false })
  const groupFields = GROUPS.flatMap((group) => [group.text, group.number])
  assert.equal(groupFields.every((field) => world.disabled(field)), true, '三组全关则三个组的文案与时长全部禁用')
  assert.equal(world.disabled('notifyPersona'), false, '通用块的署名与开关无关，仍可改')
})

check('关掉的组会多一行"该组提醒已关闭"，开着的组没有', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const notice = world.dictionaries[0].dicts.zh.groupOff

  const allOn = world.paint({ waitingNotifyEnabled: true, reviewNotifyEnabled: true, driftNotifyEnabled: true })
  assert.equal(allOn.texts.filter((line) => line === notice).length, 0)

  const oneOff = world.paint({ reviewNotifyEnabled: false })
  assert.equal(oneOff.texts.filter((line) => line === notice).length, 1, '只给关掉的那组提示一次')
})

check('只读部署：所有控件禁用', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const model = world.calls.models.at(-1)
  const original = model.shell.bind(model)
  model.shell = () => ({ ...original(), writable: false })
  world.paint()
  assert.equal(world.calls.switches.every((sw) => sw.disabled), true)
  assert.equal(world.calls.valueFields.every((field) => field.disabled), true)
})

check('布尔字段没值（空串）时按"默认开"显示，而不是显示成关闭', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  world.paint({ waitingNotifyEnabled: undefined, reviewNotifyEnabled: undefined, driftNotifyEnabled: undefined })
  assert.deepEqual(world.calls.switches.map((sw) => sw.checked), [true, true, true])
})

// ── 6. 硬性 UI 要求 ───────────────────────────────────────────────────────
check('渲染结果里没有「故障」字样（该功能不可关闭，界面不提供任何选项）', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const zh = visibleCopy(world, world.paint().texts)
  assert.ok(!zh.includes('故障'), '配置页必须完全不提故障提醒')
  // "default" 里含 "fault"，所以英文按整词匹配
  world.setLocale('en')
  const en = visibleCopy(world, world.paint().texts)
  world.setLocale('zh')
  assert.ok(!/\bfault\b/i.test(en), '英文页同样不能出现故障提醒')
  assert.ok(!/\bfailure\b/i.test(en), '也不该有 failure 相关的措辞')
})

check('渲染结果里没有旧配置键名，也没有故意不上界面的键', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const zh = visibleCopy(world, world.paint().texts)
  for (const key of BANNED_KEYS) assert.ok(!zh.includes(key), `界面上不该出现 ${key}`)
  for (const field of world.calls.valueFields) {
    for (const key of BANNED_KEYS) assert.ok(!field.id.includes(key), `控件 id 里不该出现 ${key}`)
  }
})

check('文案带单位：中文毫秒/分钟，英文 (ms)/(minutes)', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const zh = visibleCopy(world, world.paint().texts)
  assert.ok(zh.includes('毫秒'), '①② 的时长要标毫秒')
  assert.ok(zh.includes('分钟'), '③ 的时长要标分钟')
  world.setLocale('en')
  const en = visibleCopy(world, world.paint().texts)
  world.setLocale('zh')
  assert.ok(en.includes('(ms)'))
  assert.ok(en.includes('(minutes)'))
})

check('三组标题与通用块都渲染出来了', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const copy = visibleCopy(world, world.paint().texts)
  const zh = world.dictionaries[0].dicts.zh
  for (const key of ['generalTitle', 'waitingTitle', 'reviewTitle', 'driftTitle']) {
    assert.ok(copy.includes(zh[key]), `缺了 ${key} 的标题`)
  }
  // 每组标题各一次
  assert.equal(copy.split(zh.waitingTitle).length - 1, 1)
  assert.equal(copy.split(zh.driftTitle).length - 1, 1)
})

// ── 7. 字典与 jsx 调用规范 ────────────────────────────────────────────────
check('zh / en 字典键集一致，每条都是非空字符串，且渲染用到的键都在', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  world.setLocale('en')
  world.paint()
  world.setLocale('zh')
  world.paint()
  const { zh, en } = world.dictionaries[0].dicts
  assert.deepEqual(new Set(Object.keys(zh)), new Set(Object.keys(en)))
  for (const [locale, dict] of [['zh', zh], ['en', en]]) {
    for (const [key, value] of Object.entries(dict)) {
      assert.equal(typeof value, 'string', `${locale}.${key} 应是字符串`)
      assert.ok(value.length > 0, `${locale}.${key} 不应为空`)
    }
  }
  assert.deepEqual([...world.missingKeys], [], '渲染过程中有取不到的字典键')
  // 字段名与提示键必须成对存在
  for (const field of EXPECTED_FIELDS) {
    assert.ok(zh[field] && en[field], `${field} 缺 label`)
    if (!field.endsWith('Enabled')) assert.ok(zh[`${field}Hint`] && en[`${field}Hint`], `${field} 缺 hint`)
  }
})

check('jsx 调用规范：key 只走第三个参数，没有重复 key', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  world.paint()
  world.paint({ waitingNotifyEnabled: false, reviewNotifyEnabled: false, driftNotifyEnabled: false })
  assert.deepEqual(world.calls.duplicateKeys, [], 'config 里和第三个参数里同时给 key 属于不规范写法')
})

console.log(`\nclient: ${passed} 项全部通过\n`)
