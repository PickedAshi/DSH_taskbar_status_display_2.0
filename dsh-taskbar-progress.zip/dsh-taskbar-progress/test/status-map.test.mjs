/**
 * 纯函数单测：状态映射表 + 聚合优先级。
 * 不依赖 DSH、不碰任务栏，`node test/status-map.test.mjs` 直接跑。
 */

import assert from 'node:assert/strict'
import {
  PHASE,
  PHASE_SPEC,
  TBPF,
  MODE_TO_TBPF,
  aggregatePhases,
  specFor,
  tbpfFor,
  isPhase,
  fractionToValue,
} from '../lib/status-map.js'

let passed = 0
const check = (label, fn) => {
  fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}

console.log('status-map')

check('working → indeterminate / TBPF_INDETERMINATE', () => {
  assert.deepEqual(PHASE_SPEC[PHASE.WORKING], { mode: 'indeterminate', value: 2 })
  assert.equal(tbpfFor(PHASE.WORKING), TBPF.INDETERMINATE)
})

check('error → error / TBPF_ERROR', () => {
  assert.deepEqual(PHASE_SPEC[PHASE.ERROR], { mode: 'error', value: 1 })
  assert.equal(tbpfFor(PHASE.ERROR), TBPF.ERROR)
})

check('waiting → paused / TBPF_PAUSED（Windows 没有蓝色档）', () => {
  assert.deepEqual(PHASE_SPEC[PHASE.WAITING], { mode: 'paused', value: 1 })
  assert.equal(tbpfFor(PHASE.WAITING), TBPF.PAUSED)
})

check('done → normal / TBPF_NORMAL', () => {
  assert.deepEqual(PHASE_SPEC[PHASE.DONE], { mode: 'normal', value: 1 })
  assert.equal(tbpfFor(PHASE.DONE), TBPF.NORMAL)
})

check('idle → 清除（mode none / value -1 / TBPF_NOPROGRESS）', () => {
  assert.deepEqual(PHASE_SPEC[PHASE.IDLE], { mode: 'none', value: -1 })
  assert.equal(tbpfFor(PHASE.IDLE), TBPF.NOPROGRESS)
})

check('mode → TBPF 表覆盖全部 mode 且值正确', () => {
  assert.deepEqual(MODE_TO_TBPF, {
    none: 0x0,
    indeterminate: 0x1,
    normal: 0x2,
    error: 0x4,
    paused: 0x8,
  })
  for (const spec of Object.values(PHASE_SPEC)) {
    assert.ok(spec.mode in MODE_TO_TBPF, `mode ${spec.mode} 缺少 TBPF 映射`)
  }
})

check('聚合优先级 error > waiting > working > done > idle', () => {
  assert.equal(aggregatePhases([]), PHASE.IDLE)
  assert.equal(aggregatePhases([PHASE.IDLE]), PHASE.IDLE)
  assert.equal(aggregatePhases([PHASE.IDLE, PHASE.DONE]), PHASE.DONE)
  assert.equal(aggregatePhases([PHASE.DONE, PHASE.WORKING]), PHASE.WORKING)
  assert.equal(aggregatePhases([PHASE.WORKING, PHASE.WAITING]), PHASE.WAITING)
  assert.equal(aggregatePhases([PHASE.WAITING, PHASE.ERROR]), PHASE.ERROR)
  // 与顺序无关
  assert.equal(aggregatePhases([PHASE.ERROR, PHASE.IDLE, PHASE.WORKING]), PHASE.ERROR)
  assert.equal(aggregatePhases([PHASE.IDLE, PHASE.WORKING, PHASE.ERROR]), PHASE.ERROR)
})

check('未知相位：specFor 回落 idle，聚合时被忽略', () => {
  assert.deepEqual(specFor('nonsense'), PHASE_SPEC[PHASE.IDLE])
  assert.equal(isPhase('nonsense'), false)
  assert.equal(isPhase(PHASE.WAITING), true)
  assert.equal(aggregatePhases(['nonsense', PHASE.DONE]), PHASE.DONE)
})

check('fractionToValue 夹取到 0..1000', () => {
  assert.deepEqual(fractionToValue(0), { completed: 0, total: 1000 })
  assert.deepEqual(fractionToValue(1), { completed: 1000, total: 1000 })
  assert.deepEqual(fractionToValue(0.5), { completed: 500, total: 1000 })
  assert.deepEqual(fractionToValue(-3), { completed: 0, total: 1000 })
  assert.deepEqual(fractionToValue(9), { completed: 1000, total: 1000 })
})

console.log(`\nstatus-map: ${passed} 项全部通过\n`)
