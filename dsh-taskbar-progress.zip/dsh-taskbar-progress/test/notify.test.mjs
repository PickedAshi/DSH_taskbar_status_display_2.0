/**
 * 系统通知载荷单测：只验证生成的 PowerShell 脚本（不 spawn 进程、不真的弹通知）。
 *   node test/notify.test.mjs
 */

import assert from 'node:assert/strict'
import { buildToastScript, DEFAULT_AUMID } from '../lib/notify.js'

let passed = 0
const check = (label, fn) => {
  fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}

console.log('toast payload')

check('默认 AUMID 是实测过的 DSH 值', () => {
  assert.equal(DEFAULT_AUMID, 'com.deepseek.dsh')
})

check('脚本带上标题/正文与来源 AUMID', () => {
  const script = buildToastScript({
    aumid: 'com.deepseek.dsh',
    title: '大肥鱼',
    text: '老大请您做出决定',
  })
  assert.ok(script.includes('<text>大肥鱼</text>'), '标题应进模板')
  assert.ok(script.includes('<text>老大请您做出决定</text>'), '正文应进模板')
  assert.ok(script.includes("CreateToastNotifier('com.deepseek.dsh')"), 'AUMID 应进调用')
  assert.ok(script.includes('ToastGeneric'), '应使用 ToastGeneric 模板')
  assert.ok(script.includes('Windows.UI.Notifications'), '应加载 WinRT 类型')
})

check('XML 特殊字符被转义（配置里带 & < > 不会破坏模板）', () => {
  const script = buildToastScript({
    aumid: 'a',
    title: 'A & B <tag> "q" \'s\'',
    text: 'x > y',
  })
  assert.ok(script.includes('A &amp; B &lt;tag&gt; &quot;q&quot; &apos;s&apos;'), script)
  assert.ok(script.includes('x &gt; y'))
  assert.ok(!script.includes('<tag>'), '原始尖括号不应出现')
})

check('AUMID 里的单引号被翻倍（不会截断 PowerShell 字符串）', () => {
  const script = buildToastScript({ aumid: "we'ird", title: 't', text: 'b' })
  assert.ok(script.includes("CreateToastNotifier('we''ird')"), script)
})

check('undefined 标题/正文不会产出 "undefined" 字样', () => {
  const script = buildToastScript({ aumid: 'a', title: undefined, text: undefined })
  assert.ok(!script.includes('undefined'), script)
})

console.log(`\ntoast payload: ${passed} 项全部通过\n`)
