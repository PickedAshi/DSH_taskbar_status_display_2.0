# dsh-taskbar-progress

**DSH 桌面端任务栏进度条状态指示插件** —— 用 Windows **原生任务栏进度条**（不是叠加图标）实时反映 Agent 状态。

| Agent 状态 | 任务栏表现 | 颜色（实测） |
| --- | --- | --- |
| 思考 / 任务中 | 循环滚动的进度条（indeterminate） | 浅蓝，滚动 |
| 等待用户选择 | 静态条（paused） | **黄色** `(218,195,9)`（系统固定） |
| 卡住 / 故障 | 故障条（error） | **红色** `(220,135,146)`（系统固定） |
| 任务完成 | 填满的进度条，保持 30 秒后清除（normal） | 浅钢蓝 `(160,174,183)` —— **不是绿色**，见第 7 节 |
| 无活动 | 进度条清除 | — |

**另外还会以「大肥鱼」的名义弹 Windows 系统通知**，一共四种（见 [四种系统通知](#四种-windows-系统通知)）：

| # | 时机 | 通知正文 | 默认 | 能不能关 |
| --- | --- | --- | --- | --- |
| ① | 等待用户选择**超过 30 秒**还没人应答 | 老大请您做出决定 | 开 | ✅ 能关，也能改文案 / 时长 |
| ② | 任务完成后 **15 秒你还没操作 DSH** | 老大请验收 | 开 | ✅ 能关，也能改文案 / 时长 |
| ③ | **连续工作满 10 分钟**且中途没有任何形式的停止 | 已经连续工作10分钟，建议检查白饭是否被偷 | 开 | ✅ 能关，也能改文案 / 分钟数 |
| ④ | **进入故障相位（立即，不计时）** | 故障，请检查 | **始终开** | ❌ **不可关闭**：文案写死，设置界面里没有任何相关选项（需求硬性要求） |

![任务栏五种状态](docs/taskbar-states.png)

> 上排到下排依次是 idle / working / waiting / error / done。
> 这张图是**直接驱动插件自己的后端代码**（也就是插件运行时调用的同一份实现）拍出来的；
> 其中 working / done / idle 三种状态另外还在**完整接线后的真实 DSH 宿主**里复现过（见文末实测记录）。
> `working`（滚动）实际是**动画**，静帧只能拍到滚动片段的一瞬间，所以看起来偏窄。

---

## 1. 先看这条：为什么不是 `win.setProgressBar()`

需求书的方案是「用 `ctx.get('window')` 拿到 BrowserWindow，再调 `setProgressBar`」。
在 DSH 0.2.0 桌面端上**这条路走不通**，证据如下：

1. **宿主服务目录里没有窗口服务。** 用 `cordis-inspect` 拉全量 Service 目录，
   `window` / `browserWindow` 之类的 key 都不存在，所以 `ctx.get('window')` 恒为 `undefined`。
2. **插件宿主跟 Electron 不是一个进程。** 真实进程拓扑：

   ```
   DeepSeek Harness.exe            ← Electron 主进程（BrowserWindow 在这里）
     └─ DeepSeek Harness.exe --expose-internals
          .../app.asar/dsh/node_modules/@deepseek-ai/dsh-desktop-host/lib/index.js
                                 ← DSH 宿主进程，整个 profile 插件树在这里加载（本插件也在这里）
   ```

   两者之间只有一条**用法固定**的 `process.send` IPC：
   `ready` / `shutdown` / `quit-inspection` / `update-tasks` / `platform-session` / `fatal`。
   没有给插件预留任何"帮我调一下窗口"的通道，Electron 主进程里也**从未**调用过 `setProgressBar`。

**那怎么办？** 任务栏进度条在 Windows 上本质是 COM 接口 `ITaskbarList3` 作用在某个**窗口句柄 HWND** 上，
而 HWND **跨进程可见**。实测：从插件所在的宿主进程对 Electron 主窗口调用
`SetProgressValue` / `SetProgressState` **返回 S_OK 并且真的生效**，且设置进程退出后状态依然保持。

所以本插件把「窗口服务」保留为**首选层**（DSH 将来若真暴露窗口服务，不改代码就会自动走那条路），
真正干活的是下面三层后端。

---

## 2. 三层后端（自动降级）

| 顺序 | 后端 | 说明 | 依赖 |
| --- | --- | --- | --- |
| 1 | `window-service` | 探测 DSH 是否暴露窗口 / BrowserWindow 服务，有就调 `setProgressBar(value, {mode})` | 无（当前版本会跳过） |
| 2 | `win32-koffi` | **实际生效的那层**：用 koffi FFI 直接调 Win32 COM `ITaskbarList3/4` | koffi（DSH 桌面端**随安装包自带**） |
| 3 | `powershell` | 兜底：常驻 PowerShell 助手 + .NET COM 互操作 | 只用 Windows 自带的 `powershell.exe` |
| 4 | `no-op` | 全都不行就降级为空操作，并在日志里说明原因 | — |

三个实测踩到的坑，都已经在代码里处理（`lib/backends/win32-koffi.js`、`lib/koffi-resolver.js`）：

* 本机 Win11 上 `CoCreateInstance(CLSID_TaskbarList)` 之后 **QI `ITaskbarList3` 返回 `E_NOINTERFACE`**，
  而 QI `ITaskbarList4`（继承自 v3）却成功。所以按 **v4 → v3 → v2** 顺序尝试。
* `ITaskbarList4` 的 vtable 里 `SetProgressValue` / `SetProgressState` 在
  `IUnknown(0..2)` + `ITaskbarList(3..7)` + `ITaskbarList2(8)` 之后，下标是 **9 / 10**。
* **`koffi.proto()` / `koffi.struct()` 是进程内按名字全局注册的，重名第二次会抛
  `Duplicate type name`。** 插件被停用再启用时会二次实例化后端 —— 不缓存类型就会静默降级到
  PowerShell。现在用 `WeakMap` 按 koffi 模块缓存，只注册一次。

---

## 3. 状态映射表与信号来源

映射表的唯一事实来源是 [`lib/status-map.js`](lib/status-map.js) 顶部注释，代码与文档不会漂移：

| 相位 | 触发来源 | Electron 调用 | 原生 `TBPF_*` | 视觉 |
| --- | --- | --- | --- | --- |
| `working` | `agent/status` → `running`；`api-session/status` → `running=true`；轮询 `ctx.agents` | `setProgressBar(2, {mode:'indeterminate'})` | `TBPF_INDETERMINATE` (0x1) | 滚动 |
| `error` | `api-session/error`；`agent/error` | `setProgressBar(1, {mode:'error'})` | `TBPF_ERROR` (0x4) | 红色 |
| `waiting` | 见下方三条路径 | `setProgressBar(1, {mode:'paused'})` | `TBPF_PAUSED` (0x8) | 黄色静态 |
| `done` | `running` → `idle` 的一次转换 | `setProgressBar(1, {mode:'normal'})` | `TBPF_NORMAL` (0x2) | 填满，保持 30s |
| `idle` | 无活动 / 保持期结束 / 插件停用 | `setProgressBar(-1)` | `TBPF_NOPROGRESS` (0x0) | 清除 |

### 「等待用户」为什么有三条路径

需求书原本只写了监听 `user-questions/request` waterfall。**实测只监听它是不够的**：

服务契约里写得很清楚 —— `ctx.userQuestions.ask()` 才走 "scoped answerer waterfall"，
而 `ask_user_question` **工具**用的是 `askTimed()`，描述是
"Foreground wait **whose first settlement the Client decides**"（首次结算由 Client 决定）。
它**不一定派发** `user-questions/request`。实测出现过两种结果：早先几轮交互式问答里，
插件**整整一轮都没收到**该事件（旧版本因此完全不亮）；后来又观察到它会**迟几毫秒**到达。
结论很简单：**不能只依赖它**，需要一个每次必然发生的信号。

于是现在同时接三条：

| 路径 | 覆盖场景 |
| --- | --- |
| `tools/execute`（around-dispatch，判断工具名 ∈ `waitingTools`） | **交互式提问实际走这条** |
| `user-questions/request`（waterfall 观察） | `ask()` 路径（例如 plan review） |
| `approval/request`（waterfall 观察） | 审批 / 授权确认 |

三条都是**观察性透传**：原样 `return await next()`，不代答、不改变下游结果。

**多会话聚合优先级**：`error(4) > waiting(3) > working(2) > done(1) > idle(0)`
（任务栏只有一个进度条，取"最需要被看到"的那个）。

**子代理隔离**：默认 `scope: 'roots'`，只认 `ctx.agents.roots()` 里的顶层会话；
子代理的 `agent/status` / 报错不会污染顶层状态。

**粘性错误**：`lastAgentError` 是粘性的，所以故障信号按**内容签名去重** —— 内容没变不重复触发，
内容变了视为新故障并刷新保持期。

**完成 vs 拆卸**：只有"显式 idle"才算任务完成；会话被关闭 / 从注册表消失属于拆卸，不会点亮完成条。

### 四种 Windows 系统通知

四条通知共用同一套发送实现（见本节末尾），但**开关规则分两类**：
①②③ 是可关闭的业务提醒，④ 是"必须让你知道"的故障——**需求上不允许用户关掉它**。

| # | 触发时机 | 默认文案 | 相关配置键 | 能不能关 |
| --- | --- | --- | --- | --- |
| ① | 进入 `waiting` 后超时 | 老大请您做出决定 | `waitingNotifyEnabled` / `waitingNotifyText` / `waitingNotifyDelayMs` | 能 |
| ② | 进入 `done` 后超时，且判定你没在操作 DSH | 老大请验收 | `reviewNotifyEnabled` / `reviewNotifyText` / `reviewNotifyDelayMs` | 能 |
| ③ | 连续工作满 N 分钟，中途没有任何停止 | 已经连续工作10分钟，建议检查白饭是否被偷 | `driftNotifyEnabled` / `driftNotifyText` / `driftNotifyMinutes` | 能 |
| ④ | 进入 `error` —— **立即**，不计时 | 故障，请检查（写死在代码里） | **无** | **不能** |

#### 通知一：等待用户选择超时

黄色条亮着说明"在等你"，但你可能正在看别的地方。所以进入 `waiting` 之后开始计时，
**超过 `waitingNotifyDelayMs`（默认 30 秒）还没人应答**，就弹一条 Windows 系统通知：

> **DeepSeek Harness** ← 来源名（由 `notifyAumid` 决定）
> **大肥鱼** ← `notifyPersona`
> 老大请您做出决定 ← `waitingNotifyText`

行为细节：

* **每段等待只提醒一次**；用户作答后相位离开 `waiting`，下次再等会**重新计时**。
* `waitingNotifyEnabled: false` 关掉这一条；`waitingNotifyDelayMs: 0` 同样等于关闭。

#### 通知二：任务完成后你没在操作 DSH

任务跑完时你多半已经切走了。所以完成态亮起后等 `reviewNotifyDelayMs`（默认 15 秒）：

> **DeepSeek Harness**
> **大肥鱼**
> 老大请验收 ← `reviewNotifyText`

**"没在操作" 是怎么判定的**（这点必须说清楚，因为插件做不到完全精确）：

插件跑在 DSH 宿主进程里，**看不到"这次输入是否指向 DSH 窗口"** —— 那要给窗口挂消息钩子
（`SetWindowsHookEx`／子类化），跨进程且侵入性大，不适合插件。所以用两个**真实可测**的系统信号做代理：

| 信号 | 取法 | 含义 |
| --- | --- | --- |
| 前台窗口是不是 DSH | `GetForegroundWindow()` + `GetWindowThreadProcessId()` 比 **PID**（不是比 HWND，这样设置窗口也算 DSH） | 你此刻是不是在 DSH 上 |
| 距上次输入多久 | `GetLastInputInfo()`（**全系统**键盘/鼠标） | 你最近有没有动过键鼠 |

判定规则（`lib/activity.js` 里的 `isUserEngaged`，纯函数、可单测）：

> **"正在操作 DSH" = DSH 是前台窗口 且 在这个时间窗内有过输入**

于是：

* 切去别的程序 → 提醒 ✓
* 人离开电脑（无输入）→ 提醒 ✓
* 盯着 DSH 并且刚动过键鼠 → 不打扰 ✓
* **探测失败**（PowerShell 不可用等）→ **fail-open，照常提醒**：宁可多提醒一次，
  也不要把"任务完成了"这件事吞掉。

注意 `reviewNotifyDelayMs` **既是"等多久"，也是"多久内算操作过"的时间窗** —— 两者语义一致
（"这 15 秒内没被操作"），所以合成一个配置项。设为 `0` 关闭，或 `reviewNotifyEnabled: false` 关掉整条。

#### 通知三：偏离纠正（连续工作太久，v2.0 新增）

前两条管的是"停下来之后"，这一条管的是**一直没停**：连续工作太久通常意味着已经跑偏了。
`working` 段开始计时，满 `driftNotifyMinutes`（默认 10 分钟）就提醒：

> **DeepSeek Harness**
> **大肥鱼**
> 已经连续工作10分钟，建议检查白饭是否被偷 ← `driftNotifyText`

**"中途没有任何形式的停止"是这条通知的关键语义**，实现上就是看相位有没有离开 `working`：

| 中途发生的事 | 相位变化 | 对计时的影响 |
| --- | --- | --- |
| 等你做选择 | `working` → `waiting` | 计时取消，归零 |
| 故障 | `working` → `error` | 计时取消，归零 |
| 任务完成 | `working` → `done` | 计时取消，归零 |
| 空闲 / 会话消失 | `working` → `idle` | 计时取消，归零 |

也就是说它度量的是**一段不中断的工作**：每个连续工作段只提醒一次，一旦出现任何停止，
下次重新跑满才会再提醒。关掉：`driftNotifyEnabled: false`；改时长：`driftNotifyMinutes`。

#### 通知四：故障（v2.0 新增）—— **不可关闭、不可配置**

进入 `error` 相位就**立即**发一条，没有等待时间、没有开关：

> **DeepSeek Harness**
> **大肥鱼**
> 故障，请检查

为什么把它做成"关不掉"的：需求原文是「卡死后立即发消息说"故障，请检查"，**用户不得关闭该功能，
设置界面不用加入此功能的选项**」。所以：

* 正文写死在 `lib/index.js` 的 `FAILURE_NOTICE_TEXT`，**配置里塞 `failureNotifyEnabled: false`
  之类的东西也照样发**（这些键根本不认识，只会被 `normalizeConfig` 当成未知项警告后忽略）；
* 它**不在 `CONFIG_DEFAULTS` 里，也不在 `lib/config-schema.js` 里** ——
  于是它不会出现在设置界面上，用户无从修改；
* `lib/client.js`（浏览器半边）里也**故意没有任何**关于它的字段、开关或说明块。

这条与"粘性错误按内容签名去重"是配套的：**同一个故障只弹一次**，内容变了才算新故障、再弹一次
（否则轮询/重复事件会把通知刷屏）。

### 四条通知共同的实现与两个坑

1. 插件宿主是纯 Node，既没有 Electron 的 `Notification` 也够不到主进程；
   而 **Windows PowerShell 5.1 原生能加载 WinRT 类型**，所以用一次性 PowerShell 子进程发 toast。
   脚本用 `-EncodedCommand`（UTF-16LE base64）传入 —— 中文才不会乱码，也绕开执行策略与引号转义。
2. **`CreateToastNotifier(aumid)` 要求 AUMID 已注册**，否则 `Show()` 照样返回成功但**什么都不弹**。
   DSH 桌面端注册的是 `com.deepseek.dsh`（来源显示为 "DeepSeek Harness"）。
   查自己的：`Get-StartApps | Where-Object Name -like '*DeepSeek*'`。

`Show()` 是立即返回的、toast 归 shell 所有，所以子进程发完就退出，**不需要常驻助手**。
通知只是锦上添花：发送失败只打一条日志，**绝不影响进度条本身**。

---

## 4. 安装

> 宿主端插件，**装完要重启 DSH 桌面端**才生效（只关窗口不算退出）。

### ⚠️ 先纠正一个常见误解：`dsh plugin --profile desktop` 用不了

`desktop` profile 是**桌面端应用专属**的。用独立装的 `dsh` CLI 去操作它会被直接拒绝：

```
$ dsh plugin --profile desktop add file:C:/path/x.tgz
error: profile "desktop" is managed exclusively by the Electron application
```

（源码里 `dsh-desktop-host/lib/cli.js` 给自己的 CLI 传了 `manageDesktopProfile: true`，
独立 CLI 没有这个开关，所以拒绝。本机实测确认。）

**所以装桌面端插件只能走桌面端自己的「插件」页。**

### 正确装法：桌面端「插件」页 + 一个 spec

打开 DSH 桌面端 → 左侧栏的 **「插件」** 页 → 安装/添加插件，把下面任一种 **spec** 填进去：

| 形式 | 例子 | 装完能不能删源文件 |
| --- | --- | --- |
| **tarball（推荐）** | `C:/path/dsh-taskbar-progress-2.0.0.tgz` | ✅ 能，装完删掉整个目录都行 |
| 目录路径（等价 `link:`） | `C:/path/dsh-taskbar-progress` | ❌ 那个目录不能删也不能挪 |

规则来自插件管理器自己的 `parseInstallSpec`（`lib/types/install-spec.js`），实测结论：

* **必须是绝对路径**；相对路径一律拒绝（`a local path must be absolute`）。
* `file:` / `link:` 前缀**可有可无**，有也会被剥掉。
* 路径以 `.tgz` / `.tar.gz` 结尾 → 按 **tarball** 装（解包进 profile，源文件可删）；
  否则按 **目录** 装（junction，源目录必须保留）。
* 也支持注册表包名、git 地址（`github:user/repo`、`git@…`、仓库 URL）。
* 装不上时会先 `inspect` 一遍，spec 不合法会直接报 `invalid-spec` 并说明原因。

**⚠️ v2.0 起，装法还决定"有没有设置界面"**（新增的依赖只喂设置界面，详见下面的小节）：

| 安装方式 | 设置界面 | 进度条 + 四种通知 |
| --- | --- | --- |
| **`.tgz`（推荐，也是分发方式）** | ✅ 有 | ✅ 正常 |
| `link:` / 目录路径 | ❌ 没有（控制台会打一条 warning） | ✅ 正常 |

### v2.0 的设置界面：在哪儿、怎么用

**位置：DSH 桌面端 → 左侧栏「插件」页 → `dsh-taskbar-progress` → 「配置」。**

页面里有四块（通用 + 三组提醒，**故障那一组故意不存在**）：

* **通用**：只有 `notifyPersona`（通知署名，可改）一个输入框。
  ⚠️ **`notifyAumid` 不在界面上**：通知来源 AUMID 必须是一个**系统已注册**的值，
  否则 toast 会静默不显示，所以它被排除在设置 schema 之外（页面上连只读展示都没有），
  要改只能写 profile 的 `cordis.patch.yml`；
* **① 等待超时提醒** / **② 完成后未验收提醒** / **③ 偏离纠正提醒**：每组一个开关 + 一个文案输入框
  + 一个时长输入框（①② 是毫秒，③ 是分钟）；
* **依赖逻辑**：**某一组的开关关掉后，该组的文案与时长输入框会变灰禁用**，并提示
  "该组提醒已关闭 —— 打开上面的开关才能修改下面的设置"。这样"关了开关却还以为改了时长生效"
  这种误解在界面上就不可能发生。
* 保存是**暂存表单模型**：改完点保存才写入 profile 的 cordis patch；
  每个字段旁边有"已覆盖 / 恢复默认"（`overridden` / `reset`），
  留空即清除覆盖、回到默认值。

实现方式（想改这个页面的话看这里）：

| 位置 | 作用 |
| --- | --- |
| `lib/client.js` | **浏览器半边**（v2.0 新增）。注册进插件页声明的 `plugins.row.config` slot，key 是 `<包名>#<行id>`，即 `dsh-taskbar-progress#taskbar-progress` |
| `lib/config-schema.js` | **宿主半边**（v2.0 新增）。用 `@deepseek-ai/schemastery` 声明哪些字段是 `.volatile()` 的 —— **表单只展示 volatile 字段**，没有 schema 这个「配置」页就是空的。它**只列需要给用户调的键**（所以 AUMID 也不在里面），进度条那批开发者选项继续走 patch |
| `lib/index.js` | `apply()` 里用 `ctx.inject(['settings'], …)` + `settings.configure({ auto: false })` 告诉 DSH「本插件自带配置页，别按 schema 自动生成」；这步失败只打日志，不影响进度条 |

界面用的都是 DSH 自带的客户端包（`@deepseek-ai/dsh-client-ui-primitives` 的
`SettingsForm` / `SettingsValueField` / `Switch`，加 `ctx.configForms` 的暂存表单模型），
所以**不需要往插件里塞任何前端依赖**。

**为什么 `link:` / 目录安装没有设置界面**：`lib/config-schema.js` 要
`import '@deepseek-ai/schemastery'`，而它由 **DSH 运行时自带**（挂在 profile 的
`node_modules/@deepseek-ai/*`）。`link:` 装出来的插件真实位置在 profile 之外，
ESM 解析不到这个包。v2.0 因此把这次 import 做成**动态 import + try/catch 降级**：

* 解析得到 → 有设置界面；
* 解析不到 → `Config` 置空、打一条 warning（"未能加载配置 schema…设置界面不可用；
  进度条与系统通知不受影响"），**插件本体照常加载，进度条和四种通知全部正常**。

这样做是因为：静态 import 一旦失败，宿主会报 `failed to import`，**连进度条都没了**
（这正是老版本那条坑，见第 8 节）。想要设置界面就**用 `.tgz` 安装**。

### 给自己开发用

改代码想让改动立刻生效，用**目录 spec**（等价 `link:`）指向工作目录最方便。
⚠️ 但要记住：**改了源码必须重启 DSH**，插件管理器上的启用/停用只对
"第一次加载失败过"的模块有效（原因见第 8 节）。

### ⚠️ 关于 `link:` / 目录安装（很重要，踩过）

`link:` 建的是 **junction / 符号链接**，而 Node 的 ESM 解析默认会把链接**还原成真实路径**
（`--preserve-symlinks` 未开）。于是：

* 插件装在 profile 里，**真实位置**却在 profile 之外；
* DSH 运行时包挂在 `~/.dsh/profiles/node_modules/@deepseek-ai/*`，
  从真实位置向上找**找不到**。

所以 **`link:` 安装的插件绝对不能静态 `import '@deepseek-ai/*'`** —— 会直接
`ERR_MODULE_NOT_FOUND`，宿主报 `failed to import`，插件**整个加载不起来**
（症状是任务栏毫无反应，且日志里只有一句 "failed to import"）。
作为对照：从 GitHub 装成真实目录的插件（如 `dsh-embedded-browser`）就没这个问题。

**本插件的宿主功能仍然是零第三方依赖**：进度条的后端选择、状态机、配置校验
（`lib/index.js` 的 `normalizeConfig`）全都只用 `node:` 内置模块，
不碰任何 `@deepseek-ai/*` 包，所以 `link:`、复制、npm 安装都能跑。

v2.0 新增的 `@deepseek-ai/schemastery` 依赖是**唯一的例外，而且只用于生成设置界面**：

* 它是 **DSH 运行时自带**的包，不需要用户联网安装，也不进 `dependencies`；
* 用**动态 `import()` + `try/catch`** 拿（见 `lib/index.js` 顶部）：拿不到就安静降级；
* 于是 `link:` / 目录安装的插件**宿主功能一个不少**，只是没有设置界面（见上一小节）。

换句话说：**旧文档里那种"连 `@deepseek-ai/schemastery` 都不敢 import"的限制，v2.0 已经换成了
"import 失败也绝不拖垮插件"**。

### 打包发给别人

**可以直接打包发出去。** 宿主功能零第三方依赖，所以收到的人**不需要联网装任何东西**
（设置界面用的 schemastery 在他自己的 DSH 运行时里就有），
只要他自己的 DSH 是桌面端 0.2.0 附近版本、系统是 Windows。

推荐：打一个 zip，里面放 **tgz + 源码 + 一份中文安装说明**（本机已实测走通全流程）：

```
dsh-taskbar-progress-v2.0.0/
├── INSTALL.txt                       # 中文安装说明（对方先读这个）
├── dsh-taskbar-progress-2.0.0.tgz    # 推荐用它安装（也才有设置界面）
└── dsh-taskbar-progress/             # 完整源码（备用/阅读/跑自测）
```

```powershell
# 你这边
pnpm pack                                  # → dsh-taskbar-progress-2.0.0.tgz
Compress-Archive -Path <上面那个目录> -DestinationPath <桌面>\....zip
```

> ⚠️ **以后改版本号时记得同步本文档**：`package.json` 的 `version` 决定 pack 出来的文件名，
> 而文档里多处引用了这个文件名。

对方那边（**注意：不是命令行**，见第 4 节，`desktop` profile 只归桌面端管）：

1. 解压 zip 到任意位置；
2. 打开 DSH 桌面端 → 左侧栏 **「插件」** 页 → 安装，粘贴解压出来的 tgz 的**绝对路径**：
   `D:/dsh-plugin/dsh-taskbar-progress-v2.0.0/dsh-taskbar-progress-2.0.0.tgz`
3. **完全退出并重新打开** DSH；
4. 装完那个解压目录可以整个删掉。

实测结论：

* DSH 插件管理器自己的 `parseInstallSpec` 把该路径判定为 `tarball`（合法）；
* pnpm 会把包**解包进他自己的 profile**（`profiles/desktop/node_modules/.pnpm/...`），
  装完**删掉 tgz 也照样能用**，`import` 正常、包内 121 项自测可跑；
* 包内没有指向你机器的路径（`lib/` 里零硬编码路径），zip 内条目名全 ASCII 不会乱码。

也支持直接发**解压后的文件夹**（对方在「插件」页填文件夹绝对路径），
但要提醒对方：**那个文件夹不能删也不能挪**，否则链接断掉、插件失效 ——
而且这种装法**没有设置界面**（原因见上一小节）。所以**分发首选 tgz**。

需要注意的四点：

1. **必须重启 DSH** 才生效（宿主端插件）。
2. **只在 Windows 桌面上有效**；纯 `dsh web` 或非 Windows 会安静降级为 no-op。
3. 通知功能依赖 AUMID：如果对方 DSH 的 AUMID 不是 `com.deepseek.dsh`（不同构建可能不同），
   通知会静默不显示 —— 让他跑 `Get-StartApps | Where-Object Name -like '*DeepSeek*'` 查出来，
   配到 `notifyAumid` 即可。**进度条本身不受影响。**
4. **想要设置界面就用 tgz 装**（文件夹 / `link:` 装出来没有界面，但进度条和四种通知照常）。

---

## 5. 配置

两个地方都能改，**写入的是同一个 profile cordis patch**：

* **图形界面**：桌面端 → 「插件」页 → `dsh-taskbar-progress` → 「配置」（只列通知相关的键，见第 4 节）；
* **直接写 patch**：`%USERPROFILE%\.dsh\profiles\desktop\cordis.patch.yml` 里按 row id 覆盖。
  界面保存后也是写回这里，所以用界面改完能在文件里看到结果，两边不会各说各话。

```yaml
- id: taskbar-progress
  config:
    completion: hold            # hold(默认，填满后保持) | clear(立即清除)
    completionHoldMs: 30000     # 保持时长
    errorHoldMs: 60000          # 故障条自动消退；0 = 不自动消退
    flashOnWaiting: false       # 等待用户时同时闪烁任务栏按钮(FlashWindowEx)
    flashOnError: false
    scope: roots                # roots(默认，只看顶层会话) | all
    waitingTools:               # 视为"等待用户"的工具
      - ask_user_question
    pollMs: 1500                # ctx.agents 轮询间隔(降级方案)
    reassertMs: 20000           # 每隔多久重发一次当前相位(自愈)；0 = 关闭
    backend: auto               # auto | window | koffi | powershell | none
    logStateChanges: true
    targetPid: 0                # 0 = 自动(process.ppid，桌面端即 Electron 主进程)
    enabled: true               # 总开关
    debugLogFile: ""            # 诊断日志(JSONL)路径；空 = 关闭

    # —— Windows 系统通知（四条共用前两项）——
    notifyPersona: "大肥鱼"                 # 通知第一行(加粗)的"发信人"；四条通知共用
    notifyAumid: "com.deepseek.dsh"         # 通知来源用的 AUMID（必须已注册）

    # ① 等待用户超时
    waitingNotifyEnabled: true              # 开关；false 时本组文案与时长一律不生效
    waitingNotifyText: "老大请您做出决定"     # 正文
    waitingNotifyDelayMs: 30000             # 等这么久还没人应答就弹；0 也等于关闭

    # ② 完成后你还没验收
    reviewNotifyEnabled: true               # 开关；false 时本组设置不生效
    reviewNotifyText: "老大请验收"           # 正文
    reviewNotifyDelayMs: 15000              # 完成后等这么久；既是等待时长也是"多久内算操作过"；0 也等于关闭

    # ③ 偏离纠正：连续工作太久（v2.0 新增）
    driftNotifyEnabled: true                # 开关；false 时本组设置不生效
    driftNotifyText: "已经连续工作10分钟，建议检查白饭是否被偷"
    driftNotifyMinutes: 10                  # 连续工作满这么多分钟、中途没有任何停止才提醒

    # ④ 故障提醒：**这里没有它的键，也不会有** —— 文案写死、不可关闭（见第 3 节）
```

**从 v1.2.0 升级上来的话，四个旧键名已废弃**（写了也不报错，但不会生效 ——
`normalizeConfig` 会当成未知配置项警告后忽略）：

| v1.2.0 旧键 | v2.0 新键 |
| --- | --- |
| `waitingReminderMs` | `waitingNotifyDelayMs` |
| `waitingReminderText` | `waitingNotifyText` |
| `completionNudgeMs` | `reviewNotifyDelayMs` |
| `completionNudgeText` | `reviewNotifyText` |

v2.0 另新增了 `waitingNotifyEnabled` / `reviewNotifyEnabled` / `driftNotifyEnabled` 三个开关与
`driftNotifyText` / `driftNotifyMinutes`；④ 故障通知则**没有、也不会有配置键**。

非法值不会让插件挂掉：`normalizeConfig` 会回落默认值并打一条警告。
设置界面上改的值是 **volatile 盒子**（每次读都取当前值），所以**改完不用重启 DSH**；
但直接改 patch 文件的**仍需重启**。

⚠️ `notifyAumid` **只能**在这里改 —— 它不在设置界面上（原因见第 4 节）。

---

## 6. 手动测试步骤（覆盖全部状态）

安装并**重启 DSH 桌面端**后，把 DSH 窗口放在能看到任务栏的位置：

| 要看到的状态 | 怎么手动触发 | 预期 |
| --- | --- | --- |
| **思考 / 任务中**（滚动） | 在任意会话里发一条会跑一会儿的消息，例如「从 1 数到 200，每个数字单独一行」 | 任务栏 DSH 图标上出现循环滚动的进度条 |
| **等待用户选择**（黄色） | 发：「用 ask_user_question 工具问我一个选择题，然后等我回答」；**先别回答** | 变黄色静态条；开了 `flashOnWaiting` 则按钮同时闪烁 |
| **等待超时通知**（①） | 接上一条，**等满 30 秒**再回答 | 弹 Windows 系统通知：标题「大肥鱼」、正文「老大请您做出决定」；整段等待只弹一次 |
| **卡住 / 故障**（红色）+ **故障通知**（④） | 让一次模型请求失败：设置里把 API Key 改错后发消息、断网后发消息、或用余额耗尽的账号 | 变红色条（`errorHoldMs` 后自动消退，或下次重新开跑即清），并且**立即**弹通知：正文「故障，请检查」——**没有等待时间，也没有开关** |
| **任务完成**（填满） | 等上一条任务正常跑完（Agent 回到 idle） | 进度条填满并保持 30 秒，然后清除 |
| **完成验收通知**（②） | 接上一条，**跑完后立刻切到别的窗口、或干脆离开电脑 15 秒** | 弹 Windows 系统通知：标题「大肥鱼」、正文「老大请验收」 |
| **（反例）不打扰** | 任务跑完后**继续在 DSH 里点一下/敲一下键**，别切走 | 15 秒后**不弹**通知（因为判定你正在操作 DSH） |
| **偏离纠正通知**（③） | 让它连续跑满 10 分钟且**中途不打断**（不要提问、不要切走触发故障）。想快点验证就把 `driftNotifyMinutes` 或界面上的分钟数改成 1 | 满点时弹通知：正文「已经连续工作10分钟，建议检查白饭是否被偷」；期间只要出现过等待/故障/完成/空闲，计时就归零，**不会**提醒 |
| **（反例）中途停一下就不算偏离** | 连续跑到快满点时，故意用 `ask_user_question` 问一次并停够一会儿 | 计时归零，之后即使继续跑满相同的分钟数，也要**重新从头计时**才会提醒 |
| **设置界面：关掉开关** | 在「插件 → dsh-taskbar-progress → 配置」里关掉 ①（或 ②/③）的开关并保存 | 该条通知不再发（比如等满 30 秒也不弹）；同时**该组的文案与时长输入框变灰禁用**，并显示"该组提醒已关闭" |
| **设置界面：改文案/时长** | 把 ① 的文案改成别的、时长改成 5000 并保存 | 下一次等待超时 5 秒就弹，正文是新文案；**不用重启 DSH** |
| **（反例）故障不可关** | 在设置界面里找"故障"相关的开关 | **找不到**：界面上没有任何故障通知的选项；配置里写 `failureNotifyEnabled: false` 也依然会弹「故障，请检查」 |
| **无活动**（清除） | 完成保持期结束后自动清除；或 `completion: clear` | 进度条消失，只剩 Windows 自己那条运行中下划线 |

补充：

* **窗口最小化时进度条继续显示**，这是 Windows 原生行为，插件不需要额外处理。
* Windows 的任务栏进度条**没有蓝色档**；「等待用户」用 `paused`（黄）表达。
  需要更强提醒就打开 `flashOnWaiting`（走 `FlashWindowEx`，**不是** `SetOverlayIcon`）。
* 本插件全程**不使用** `SetOverlayIcon`（叠加图标）。

### 不依赖 DSH 的独立验证

```powershell
cd <本插件目录>
node test/backend-smoke.mjs                    # 自动选后端，依次走完 5 个相位
node test/backend-smoke.mjs --ms 5000          # 每个相位停 5 秒，方便盯着看
node test/backend-smoke.mjs --phase waiting    # 只设一个相位并**保留**（方便截图核对）
node test/backend-smoke.mjs --phase idle       # 清除
node test/backend-smoke.mjs --backend powershell   # 强制走 PowerShell 兜底后端
```

目标窗口 PID 默认取 `process.ppid`；直接跑时可以用环境变量指定：

```powershell
$env:DSH_TASKBAR_TARGET_PID = "<Electron 主进程 PID>"
```

### 单元测试（不需要 DSH / 不需要 koffi）

```powershell
node test/status-map.test.mjs      # 映射表 + 聚合优先级（9 项）
node test/plugin-state.test.mjs    # 相位状态机，假时钟（20 项）
node test/reminder.test.mjs        # 延迟提醒，假定时器（9 项）
node test/notify.test.mjs          # 通知载荷 / XML 转义（5 项）
node test/activity.test.mjs        # "没在操作 DSH" 判定（10 项）
node test/config.test.mjs          # 配置规整 / volatile 盒子（10 项）
node test/client.test.mjs          # 浏览器半边结构级回归（22 项）
node test/plugin-wiring.test.mjs   # 事件接线 + 配置 + 四种通知（36 项）
```

共 **121 项**。也可以 `pnpm test` 一次跑完。

`config.test.mjs` 专门盯 v2.0 的**volatile 盒子**语义：设置界面保存的值在 Cordis 里不是裸值，
而是一个要 `.get()` 的盒子（`JSON.stringify` 出来是 `{}`）。它验证四件事 ——
裸值照旧能用（`link:` 安装退化时就是这种形态）、盒子能被解包、**换值后重新读就是新值**
（所以"改完不用重启"不是玄学）、盒子里是坏值就回落默认值而不是把坏值喂给插件。

`plugin-wiring.test.mjs` 用**假 Cordis 上下文**驱动真实的 `apply()`，并且用
`setToastTransport()` 注入假通知发送器 —— 所以"什么时候该弹、弹几条、文案对不对"
全部可断言，**不真的弹通知、也不 spawn 进程**。v2.0 新增的用例覆盖：
故障立即弹且关不掉、连续工作到点提醒、中途停止就归零、三组开关各自能关、
以及同一个故障不重复刷屏。

---

## 7. 已知限制 / 注意事项

* **只在 Windows 上有效。** 非 Windows 平台三个后端都会跳过，插件降级为 no-op。
* **需要 DSH 桌面端（Electron）**。纯 `dsh web` 没有 Electron 窗口，任务栏上没有属于它的按钮，
  插件找不到目标窗口 —— 同样降级为 no-op。
* **颜色不完全由我们决定**：`TBPF_*` 只有 4 档（indeterminate / normal / paused / error），
  **没有任何颜色参数**。本机实测（Win11，任务栏不使用强调色）各档取色：

  | 相位 | `TBPF_*` | 实测均值 RGB | 观感 |
  | --- | --- | --- | --- |
  | waiting | `TBPF_PAUSED` | `(218, 195, 9)` | **亮黄**（系统固定） |
  | error | `TBPF_ERROR` | `(220, 135, 146)` | **红/粉**（系统固定） |
  | done | `TBPF_NORMAL` | `(160, 174, 183)` | 浅钢蓝（**不是绿色**） |
  | idle | `TBPF_NOPROGRESS` | `(117, 126, 135)` | 只剩系统那条灰色"运行中"下划线 |

  也就是说 **Windows 7/8 时代那个"完成 = 绿色"已经不存在了**：Win10/11 的 `NORMAL`
  呈现为浅蓝/钢灰（开启"在任务栏显示强调色"后跟随强调色）。
  想要"一定是绿色"在原生进度条上**做不到** —— 只有两条路：
  ① 把 Windows 主题色改成绿色并开启"在任务栏显示强调色"（系统级改动，影响整机 UI）；
  ② 改用叠加图标（`SetOverlayIcon`）画一个绿勾，而那正是需求书明确不要的。
  另外窗口**未获得焦点**时，进度条颜色会被系统调暗。
* **多会话**：默认 `scope: 'roots'`，任何顶层会话在跑都会亮。
* **设置界面只在 `.tgz` 安装时出现**（且要求 DSH 桌面端带客户端插件页）。
  `link:` / 目录安装时 `@deepseek-ai/schemastery` 解析不到，插件会打一条 warning 后安静降级：
  **进度条与四种通知照常工作，只是没有那个「配置」页**（见第 4 节）。
  这是**故意的降级**，不是故障 —— 静态 import 会让插件整个加载失败，那样连进度条都没了。
* **界面上只能改通知相关的键**。进度条那批开发者选项（`backend` / `pollMs` / `debugLogFile` …）
  仍然只能写 profile 的 `cordis.patch.yml`：`lib/config-schema.js` 只声明需要给用户调的字段。
* **④ 故障通知没有开关，也不打算有**：这是需求硬性要求，不是"忘了做"。
* **宿主日志**：桌面端宿主进程的 stdout 由 Electron 主进程接管，通常不落盘。
  排障请打开 `debugLogFile`（见下节）。

---

## 8. 排障

### 插件改了代码但不生效？—— 需要重启宿主

**Node 的 ESM 模块缓存会让重载拿到旧模块。** 实测：改完代码用插件管理器
disable → enable，日志显示加载的仍是旧版本（新增的配置项被当成"未知配置项"拒绝）。
用插件管理器重载只对**第一次加载失败的模块**有效（那时没有成功缓存）。
**改了插件源码就重启 DSH 桌面端。**

### 什么都看不到？按顺序查

1. **确认插件加载成功**：插件管理器里 `dsh-taskbar-progress` 的 `application` 应为 `applied`。
   若是 `failed to import`，基本只有一种成因：**`link:` 安装的插件里出现了静态 `import '@deepseek-ai/*'`**
   （见第 4 节）。v2.0 的 `@deepseek-ai/schemastery` 已经是**动态 import + try/catch**，
   解析不到只会少一个设置界面、**不会**把插件打挂。
2. **打开诊断日志**：在 profile patch 里配 `debugLogFile`，会得到一份 JSONL，看清每一步：

   ```yaml
   - id: taskbar-progress
     config:
       debugLogFile: "C:/Users/abc/taskbar-progress-debug.jsonl"
   ```

   正常的话会看到 `apply` → `backend-ready`（`backendId` 是 `win32-koffi` 还是降级的 `powershell`）
   → `win32 resolveWindow`（HWND）→ `win32 setProgress`（flags / HRESULT 都是 0）→ `phase`。
   通知相关的排查看 `notify` / `review-reminder` / `ev tools/execute(waiting)` 这几条记录。
3. **确认后端能单独驱动任务栏**：跑 `node test/backend-smoke.mjs`，与 DSH 无关。
4. **确认窗口句柄对**：`win32 resolveWindow` 报的 HWND 应该是 Electron 主进程（`process.ppid`）
   那个有标题的可见顶层窗口。
5. **进度条和通知都正常，只是没有「配置」页？** 这是预期行为，不是故障：
   `link:` / 目录安装解析不到 `@deepseek-ai/schemastery`，控制台会有一条
   "未能加载配置 schema…设置界面不可用；进度条与系统通知不受影响" 的 warning。
   改用 `.tgz` 安装即可获得设置界面（见第 4 节）。
6. **设置界面改完不生效？** 先确认点过**保存**（表单是暂存的，改完不点保存不会写回 profile）；
   再确认那个开关是打开的 —— 关掉的组，它的文案与时长输入框是**禁用**的，改了也不会生效。

---

## 9. 卸载

同样走**桌面端的「插件」页**（`dsh plugin --profile desktop` 会被拒绝，见第 4 节）：
找到 `dsh-taskbar-progress` 删除即可。删依赖但那行 patch 还在时，
就在 `cordis.patch.yml` 里给它加 `disabled: true`，或者删掉那条 `insert` 行。

停用插件时 `ctx.effect` 注册的清理逻辑会调用 `SetProgressState(TBPF_NOPROGRESS)` 把进度条移除，
PowerShell 后端还会主动结束助手进程。浏览器半边（`lib/client.js`）注册的设置页也会随插件一起卸载，
插件页里那一行就不再带「配置」入口。

---

## 10. 文件结构

```
dsh-taskbar-progress/
├── package.json                    # dsh.bundle.patch 指向 cordis.patch.yml；dsh.client 声明浏览器半边
├── cordis.patch.yml                # 挂载声明（insert 一行插件）
├── LICENSE                         # MIT
├── docs/taskbar-states.png         # 五种状态实拍
├── lib/
│   ├── index.js                    # Cordis 插件入口：事件 → 状态机 → 控制器；四种通知的接线都在这里
│   │                               #   （`normalizeConfig` 也在此导出，供配置单测直接调用）
│   ├── status-map.js               # ★ 状态映射表（唯一事实来源，纯数据）
│   ├── machine.js                  # 相位状态机（纯逻辑，不依赖 DSH，可单测）
│   ├── taskbar.js                  # 后端选择 + 相位去重下发
│   ├── reminder.js                 # 延迟提醒计时（纯逻辑，定时器可注入）
│   ├── activity.js                 # 桌面活动探测：前台窗口 + 全系统输入空闲
│   ├── notify.js                   # Windows 系统通知（toast）发送
│   ├── config-schema.js            # v2.0 新增：设置界面的 schema（唯一的 @deepseek-ai/* import）
│   ├── client.js                   # v2.0 新增：浏览器半边（设置界面，注册进 plugins.row.config）
│   ├── koffi-resolver.js           # 在 DSH 安装里定位随包发布的 koffi
│   ├── debug-log.js                # 可选的 JSONL 诊断日志（默认关闭）
│   └── backends/
│       ├── window-service.js       # 后端 1：DSH 窗口服务（当前版本通常不可用）
│       ├── win32-koffi.js          # 后端 2：koffi + COM（实际生效）
│       └── powershell.js           # 后端 3：常驻 PowerShell 助手兜底
└── test/
    ├── status-map.test.mjs         # 映射表单测（9 项）
    ├── plugin-state.test.mjs       # 状态机单测（假时钟，20 项）
    ├── reminder.test.mjs           # 延迟提醒单测（假定时器，9 项）
    ├── notify.test.mjs             # 通知载荷单测（不 spawn 进程，5 项）
    ├── activity.test.mjs           # "没在操作 DSH" 判定单测（10 项）
    ├── config.test.mjs             # 配置规整 / volatile 盒子单测（10 项）
    ├── plugin-wiring.test.mjs      # 事件接线 / 配置 / 四种通知（36 项）
    └── backend-smoke.mjs           # 后端实测工具（走真实任务栏）
```

补充两点：

* `lib/client.js` 是**打包好的浏览器半边**（`window.__ModuleLoader__.load({...})` 形态），
  `package.json` 的 `exports["./client"]` 与 `dsh.client` 段负责把它挂进桌面端；
  它内部按 locales / fields / groups / TaskbarCard / controller 几块组织，
  页面用 `@deepseek-ai/dsh-client-ui-primitives` 的 `SettingsForm` / `SettingsValueField` / `Switch`
  渲染，**不引入任何自己的前端依赖**。
* `lib/config-schema.js` 是**唯一** `import '@deepseek-ai/*'` 的文件，而且是被
  `lib/index.js` 用动态 `import()` 拉起来的 —— 所以它出问题最多只是"没有设置界面"。

---

## 11. 实测记录（本机 DSH 0.2.0-rc.2 / Windows 11）

1. `cordis-inspect` 全量 Service 目录 → **无** window / BrowserWindow 服务。
2. 进程拓扑 → 插件宿主是 `dsh-desktop-host/lib/index.js` 子进程，父进程是 Electron 主进程。
3. 从**另一个进程**对 Electron 窗口调 `ITaskbarList3/4`：
   `HrInit` / `SetProgressValue` / `SetProgressState` 全部 `S_OK`；
   截图比对确认 error→红、normal→强调色、paused→**黄**、indeterminate→滚动、NOPROGRESS→清除；
   且**设置进程退出后状态保持**。
4. 完整接线后在**真实 DSH 宿主**里跑：
   - `apply` → `backend-ready`（`win32-koffi`）→ `resolveWindow HWND=329192` → `setProgress flags=1 hrState=0`；
   - 逐帧量到**滚动片段每帧位置都在变**（`1794..1800` → `1818..1829` → `1798..1812` → `1807..1829`）→ working 生效；
   - 一轮结束时 `api-session/status running=false` + `agent/status idle` → `phase done`，
     抓帧确认进度条变**整宽条**，**30.2 秒后**（`17:59:10` → `17:59:40`）转 `idle` 并清除 → done/idle 生效；
   - 下一轮 `running=true` → `phase working` → working 再次生效。
5. **等待状态**：只监听 `user-questions/request` 的旧版本**完全不亮**（早先几轮交互式问答里
   该事件一条都没送到插件）。改为在 `tools/execute` 上观察 `ask_user_question`
   （工具派发本身必经此处，且比 waterfall 更早），并保留 waterfall 与 `approval/request` 两条路径。
6. `koffi.proto()` 同名二次注册 → 实测抛 `Duplicate type name 'DshTbHrInit'`
   （这就是重载后降级到 PowerShell 的原因）；用 `WeakMap` 缓存类型后，同一进程连续创建两次
   koffi 后端都成功。
7. `link:` 安装 + `import '@deepseek-ai/schemastery'` → 实测 `ERR_MODULE_NOT_FOUND`，
   宿主报 `failed to import`；插件改为零依赖后加载正常。
   （**这是 v1.2.0 的结论**：当时只能"完全不 import"。v2.0 换了做法 ——
   那次 import 变成动态 `import()` + try/catch，解析不到只是没有设置界面，
   进度条与通知照常，见第 4 节与第 31 条。）
8. 单测：映射表 9 项、相位状态机 20 项、接线 18 项，全部通过。

### 重启后的终验（DSH 0.2.0-rc.2 / 宿主 PID 28620 / 窗口 HWND 853464）

9. **新配置被接受**：`apply` 的 `warnings` 为空，`waitingTools` / `reassertMs` / `debugLogFile` 都读到了。
10. **koffi 修复在真实宿主里生效**：重启后首次加载 = `win32-koffi`；
    **热重载（disable → enable）之后仍然是 `win32-koffi`** —— 修复前这一步必然掉成 `powershell`。
11. **启动竞态自愈**：宿主刚起来时窗口还不存在（`resolveWindow → null`），
    之后自动重解析到 `HWND=853464` 并正常下发。
12. **working**：`setProgress flags=1 hrState=0`；与 `NOPROGRESS` 截图逐像素比对，
    按钮底带 x `1794..1824`、y `75..82` 有差异（最大像素差 128），且 10 帧内**偏移质心持续移动**
    （33.8 → 29.4 → 36.6 → 29.0 → 33.4 …）→ 滚动条确实在动。
13. **waiting（本轮修复的重点）**：`ev tools/execute(waiting) tool=ask_user_question` →
    `phase waiting` → `setProgress flags=8 hrState=0`；抓帧显示 **2.4s ~ 44.8s 持续黄色，
    x `1794..1829` 满宽 36px**；用户目视确认「黄色条」。回答后 `settled` → 回落 `working`。
14. **自愈重发**：等待期间每 20s 各重发一次（`10:14:17 / 10:14:37 / 10:14:57`），确认 `reassertMs` 生效。
15. 补充：本次运行里 `user-questions/request` **也**在 `tools/execute` 之后 9ms 到达了，
    所以两条路径同时命中 —— 但正因为它不稳定，仍以 `tools/execute` 为准（见第 5 条）。
16. **done**：跨轮次抓帧（每 0.4s）看到 `working`（短段移动）→ **`done`（整宽条，f060~f098 约 24~39s）**
    → `idle`（收窄回灰点）→ 完成态确实点亮并按保持期清除。
17. **Windows 系统通知**：`Get-StartApps` 查到 DSH 的 AUMID = `com.deepseek.dsh`；
    用**插件自己的 `lib/notify.js`** 真机弹了一次，截图确认来源显示 "DeepSeek Harness"、
    标题「大肥鱼」、正文「老大请您做出决定」，**中文无乱码**。
18. **打包分发**：`pnpm pack` 产出 338.9 KB 的 tgz；在干净目录里 `pnpm add file:<tgz>` 安装成功，
    内容解包进该目录自己的 `node_modules/.pnpm/`；**删掉 tgz 后依旧能 `import` 且单测可跑**。
19. 单测总计：映射表 9 + 状态机 20 + 延迟提醒 9 + 通知载荷 5 + 活动判定 10 + 接线 28 = **81 项全部通过**。

### 超时提醒的终验（重启后 / 宿主 PID 21992 / Electron 17596）

20. 重启后宿主重新加载新代码（koffi 已加载 → 后端仍是 `win32-koffi`）。
    提问后每 0.75s 抓一帧右下角通知区，逐帧结果：
    28.5s 干净 → **30.0s 通知滑入** → **33.8s 完整显示（DeepSeek Harness / 大肥鱼 / 老大请您做出决定）**
    → 45.0s 仍在 → 75.0s 已消失。
    **弹出时刻与 `waitingNotifyDelayMs: 30000` 完全吻合**（当时这个键还叫
    `waitingReminderMs`，v2.0 改名），整段等待**只弹了一次**（没有重复刷屏），
    用户目视确认，中文无乱码。

### 逐相位取色（重启后 / 宿主 PID 2008 / Electron 18540 / 窗口 HWND 67356）

21. 直接给该窗口依次下发 5 个相位并取条区均值（x `1698..1728`、y `76..82`）：

    | 相位 | 条区均值 RGB | 宽度 |
    | --- | --- | --- |
    | `idle`（NOPROGRESS） | `(117, 126, 135)` | 窄（系统灰点） |
    | `working`（INDETERMINATE） | `(73, 77, 86)` | 滚动段 |
    | `waiting`（PAUSED） | `(218, 195, 9)` | 满宽 36px |
    | `error`（ERROR） | `(220, 135, 146)` | 满宽 36px |
    | `done`（NORMAL） | `(160, 174, 183)` | 满宽 36px |

22. **红色实拍确认**：`error` 档在 x `1695..1730`、y `76..80` 呈 `(255,153,164)` 粉红条（截图存档）。
23. **完成态不是绿色**：`normal` 实测为浅钢蓝 `(160,174,183)`，与"绿"无关；
    本机 `ColorPrevalence=0`（任务栏不使用强调色），`AccentColor` 为 `(81,92,107)`。——
    `ITaskbarList` 没有任何颜色参数，"完成=绿色"在原生进度条上做不到。

### 桌面活动探测的真机验证

24. **负例**：探测 DSH 进程（PID 18540）返回 `{foregroundIsDsh:false, idleMs:21422}`
    → 判定"没在操作 DSH" ✓（当时 DSH 不在前台、且 21 秒无键鼠输入）。
25. **正例**：取当前前台窗口所属 PID（10276）再探测，返回 `{foregroundIsDsh:true, idleMs:37750}`
    → 前台判定正确 ✓；同时因 37s 无输入，`isUserEngaged` 仍为 `false`
    —— 正是"DSH 在前台但人已经走开"这一档，会照常提醒。
26. `SetForegroundWindow` 被 Windows 前台锁拒绝（返回 `False`），
    所以正例改用"拿当前前台窗口的 PID 去探"来验证，效果等价。

### v2.0 的回归与新增验证

27. **旧测试一条没坏**：v2.0 改了宿主接线（新增故障/偏离纠正两条通知、配置键改名）之后，
    v1.2.0 那 81 项单测**全部照旧通过**（映射表 9 / 状态机 20 / 延迟提醒 9 /
    通知载荷 5 / 活动判定 10 / 接线 28）。
28. **新增用例后全绿**：接线上新增"故障立即弹且关不掉、连续工作到点提醒、
    中途停止就归零、三组开关各自能关、同一故障不重复刷屏"等用例，接线测试从 28 变成 **36 项**；
    另外多出两套：`test/config.test.mjs`（配置规整 / volatile 盒子，**10 项**）与
    `test/client.test.mjs`（浏览器半边结构级回归，**22 项**）。
    全仓库合计 **121 项**（9 + 20 + 9 + 5 + 10 + 10 + 22 + 36）**全部通过**。本机 `npm test` 实际输出：

    ```
    status-map: 9 项全部通过
    phase machine: 20 项全部通过
    delayed reminder: 9 项全部通过
    toast payload: 5 项全部通过
    desktop activity: 10 项全部通过
    config normalization: 10 项全部通过
    client: 22 项全部通过
    plugin wiring: 36 项全部通过
    ```
29. **配置键改名**：`waitingReminderMs` / `waitingReminderText` 与
    `completionNudgeMs` / `completionNudgeText` 已废弃，改为
    `waitingNotifyDelayMs` / `waitingNotifyText`（+ 新增开关 `waitingNotifyEnabled`）与
    `reviewNotifyDelayMs` / `reviewNotifyText`（+ 新增开关 `reviewNotifyEnabled`）；
    `driftNotify*` 三个键是 v2.0 全新的。旧键名现在会被 `normalizeConfig` 报
    「未知配置项 '…'（已忽略）」并回落默认值 —— 所以**照抄旧文档的配置不会报错，但也不会生效**。
30. **"故障关不掉"由测试钉住**：用例把 `waitingNotifyEnabled` / `reviewNotifyEnabled` /
    `driftNotifyEnabled` / `failureNotifyEnabled` 全部设为 `false`，还塞了
    `failureNotifyText: '不该出现'`，然后制造一次故障 —— 结果**仍恰好弹一条**，
    且正文严格等于 `FAILURE_NOTICE_TEXT`（`故障，请检查`）。也就是说"不可关闭、文案写死"
    不是靠注释约定，而是有断言守着。`test/config.test.mjs` 里还有一条从配置侧钉：
    `normalizeConfig({ failureNotifyText, failureNotifyEnabled })` 出来**根本不含这两个键**。
31. **设置界面的降级路径**：`grep` 全仓库，`import '@deepseek-ai/*'` **只出现在
    `lib/config-schema.js` 一个文件里**，而且只有被 `lib/index.js` 顶部那句
    `await import('./config-schema.js')` 包着 try/catch 时才加载（失败 → `Config = undefined`
    + 一条 warning）。所以"没有 schemastery"最坏的后果就是少一个设置界面。
32. **`notifyAumid` 不在设置界面上**：读 `lib/client.js` 可确认，字段清单（`createSpecs()`）
    与「通用」分组里都**没有** `notifyAumid`，代码注释写明理由是"它不是一个用户可调的值 ——
    必须是已注册的 AppUserModelID，否则 toast 会静默不显示"；宿主侧的
    `lib/config-schema.js` 同样没声明它。所以 AUMID 只能写 profile 的 patch。
33. **打包体积（当前工作树）**：`npm pack --dry-run` 报打包后 `377235 B`（≈368 KiB）、
    解包 `532806 B`、共 27 个条目，其中 `docs/taskbar-states.png` 独占 298 KB。
    增量就是 v2.0 新增的 `lib/client.js`（约 18.1 KB / 491 行）与 `lib/config-schema.js`（约 2.4 KB），
    加上变长的 README 与测试。⚠️ 这是 **npm** 的口径，v1.2.0 记录的 338.9 KB 是 **pnpm pack**
    的口径，两者不宜直接相减；而且当时还没有 `client.js` / `config-schema.js` / `config.test.mjs`。

### v2.0 尚未实测的部分（写在前面，免得被当成已验过）

34. 本节 27~33 条都是**可以在本机复现的**（跑单测、跑 `npm pack --dry-run`、读源码/grep）。
    下面这些**只有代码层面的结论，没有真机记录**：
    * **设置界面在真实桌面端里的渲染与保存流程**（`lib/client.js` 注册进
      `plugins.row.config`、`ctx.configForms` 暂存表单、保存写回 profile patch）——
      本次只做了代码审查，没有在 DSH 桌面端里点过那个「配置」页；
    * **`link:` / 目录安装时那条降级 warning** —— 代码路径清楚（动态 import 失败 → 打 warning），
      但没有真的用 `link:` 装一遍复现；
    * **③ 偏离纠正与 ④ 故障通知在真实宿主里的实际弹出** ——
      行为由单测（假 ctx + 假 toast 发送器）覆盖，真机弹窗截图尚未补。
    上面的"实测记录"标题只覆盖 1~33 条；34 条是**待验证清单**。
